>⦁ All hosts files were last updated in 15 Oct, 2017. 
> 
>⦁ Hosts files are updated occasionally.
>  
>⦁  Many porn sites use different address for mobile devices, not all of them were included.
> 
> ⦁ Some porn sites have country based domains, not all of them were included.
