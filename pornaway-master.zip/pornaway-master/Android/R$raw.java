.class public final Lorg/pornaway/R$raw;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/pornaway/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "raw"
.end annotation


# static fields
.field public static final help_about:I = 0x7f060000

.field public static final help_changelog:I = 0x7f060001

.field public static final help_faq:I = 0x7f060002

.field public static final help_problems:I = 0x7f060003

.field public static final help_s_on_s_off:I = 0x7f060004


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 949
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
