.class public final Lorg/pornaway/R$styleable;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/pornaway/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "styleable"
.end annotation


# static fields
.field public static final SherlockActionBar:[I

.field public static final SherlockActionBar_background:I = 0x0

.field public static final SherlockActionBar_backgroundSplit:I = 0x1

.field public static final SherlockActionBar_backgroundStacked:I = 0xc

.field public static final SherlockActionBar_customNavigationLayout:I = 0xd

.field public static final SherlockActionBar_displayOptions:I = 0x7

.field public static final SherlockActionBar_divider:I = 0x2

.field public static final SherlockActionBar_height:I = 0x3

.field public static final SherlockActionBar_homeLayout:I = 0xe

.field public static final SherlockActionBar_icon:I = 0xa

.field public static final SherlockActionBar_indeterminateProgressStyle:I = 0x10

.field public static final SherlockActionBar_itemPadding:I = 0x12

.field public static final SherlockActionBar_logo:I = 0xb

.field public static final SherlockActionBar_navigationMode:I = 0x6

.field public static final SherlockActionBar_progressBarPadding:I = 0x11

.field public static final SherlockActionBar_progressBarStyle:I = 0xf

.field public static final SherlockActionBar_subtitle:I = 0x9

.field public static final SherlockActionBar_subtitleTextStyle:I = 0x4

.field public static final SherlockActionBar_title:I = 0x8

.field public static final SherlockActionBar_titleTextStyle:I = 0x5

.field public static final SherlockActionMenuItemView:[I

.field public static final SherlockActionMenuItemView_android_minWidth:I = 0x0

.field public static final SherlockActionMode:[I

.field public static final SherlockActionMode_background:I = 0x0

.field public static final SherlockActionMode_backgroundSplit:I = 0x1

.field public static final SherlockActionMode_height:I = 0x2

.field public static final SherlockActionMode_subtitleTextStyle:I = 0x3

.field public static final SherlockActionMode_titleTextStyle:I = 0x4

.field public static final SherlockActivityChooserView:[I

.field public static final SherlockActivityChooserView_android_background:I = 0x0

.field public static final SherlockActivityChooserView_expandActivityOverflowButtonDrawable:I = 0x2

.field public static final SherlockActivityChooserView_initialActivityCount:I = 0x1

.field public static final SherlockMenuGroup:[I

.field public static final SherlockMenuGroup_android_checkableBehavior:I = 0x5

.field public static final SherlockMenuGroup_android_enabled:I = 0x0

.field public static final SherlockMenuGroup_android_id:I = 0x1

.field public static final SherlockMenuGroup_android_menuCategory:I = 0x3

.field public static final SherlockMenuGroup_android_orderInCategory:I = 0x4

.field public static final SherlockMenuGroup_android_visible:I = 0x2

.field public static final SherlockMenuItem:[I

.field public static final SherlockMenuItem_android_actionLayout:I = 0xe

.field public static final SherlockMenuItem_android_actionProviderClass:I = 0x10

.field public static final SherlockMenuItem_android_actionViewClass:I = 0xf

.field public static final SherlockMenuItem_android_alphabeticShortcut:I = 0x9

.field public static final SherlockMenuItem_android_checkable:I = 0xb

.field public static final SherlockMenuItem_android_checked:I = 0x3

.field public static final SherlockMenuItem_android_enabled:I = 0x1

.field public static final SherlockMenuItem_android_icon:I = 0x0

.field public static final SherlockMenuItem_android_id:I = 0x2

.field public static final SherlockMenuItem_android_menuCategory:I = 0x5

.field public static final SherlockMenuItem_android_numericShortcut:I = 0xa

.field public static final SherlockMenuItem_android_onClick:I = 0xc

.field public static final SherlockMenuItem_android_orderInCategory:I = 0x6

.field public static final SherlockMenuItem_android_showAsAction:I = 0xd

.field public static final SherlockMenuItem_android_title:I = 0x7

.field public static final SherlockMenuItem_android_titleCondensed:I = 0x8

.field public static final SherlockMenuItem_android_visible:I = 0x4

.field public static final SherlockMenuView:[I

.field public static final SherlockMenuView_headerBackground:I = 0x3

.field public static final SherlockMenuView_horizontalDivider:I = 0x1

.field public static final SherlockMenuView_itemBackground:I = 0x4

.field public static final SherlockMenuView_itemIconDisabledAlpha:I = 0x6

.field public static final SherlockMenuView_itemTextAppearance:I = 0x0

.field public static final SherlockMenuView_preserveIconSpacing:I = 0x7

.field public static final SherlockMenuView_verticalDivider:I = 0x2

.field public static final SherlockMenuView_windowAnimationStyle:I = 0x5

.field public static final SherlockSearchView:[I

.field public static final SherlockSearchView_android_imeOptions:I = 0x2

.field public static final SherlockSearchView_android_inputType:I = 0x1

.field public static final SherlockSearchView_android_maxWidth:I = 0x0

.field public static final SherlockSearchView_iconifiedByDefault:I = 0x3

.field public static final SherlockSearchView_queryHint:I = 0x4

.field public static final SherlockSpinner:[I

.field public static final SherlockSpinner_android_dropDownHorizontalOffset:I = 0x5

.field public static final SherlockSpinner_android_dropDownSelector:I = 0x1

.field public static final SherlockSpinner_android_dropDownVerticalOffset:I = 0x6

.field public static final SherlockSpinner_android_dropDownWidth:I = 0x4

.field public static final SherlockSpinner_android_gravity:I = 0x0

.field public static final SherlockSpinner_android_popupBackground:I = 0x2

.field public static final SherlockSpinner_android_popupPromptView:I = 0x7

.field public static final SherlockSpinner_android_prompt:I = 0x3

.field public static final SherlockTheme:[I

.field public static final SherlockTheme_actionBarDivider:I = 0x8

.field public static final SherlockTheme_actionBarItemBackground:I = 0x9

.field public static final SherlockTheme_actionBarSize:I = 0x7

.field public static final SherlockTheme_actionBarSplitStyle:I = 0x5

.field public static final SherlockTheme_actionBarStyle:I = 0x4

.field public static final SherlockTheme_actionBarTabBarStyle:I = 0x1

.field public static final SherlockTheme_actionBarTabStyle:I = 0x0

.field public static final SherlockTheme_actionBarTabTextStyle:I = 0x2

.field public static final SherlockTheme_actionBarWidgetTheme:I = 0x6

.field public static final SherlockTheme_actionButtonStyle:I = 0x34

.field public static final SherlockTheme_actionDropDownStyle:I = 0x33

.field public static final SherlockTheme_actionMenuTextAppearance:I = 0xa

.field public static final SherlockTheme_actionMenuTextColor:I = 0xb

.field public static final SherlockTheme_actionModeBackground:I = 0xe

.field public static final SherlockTheme_actionModeCloseButtonStyle:I = 0xd

.field public static final SherlockTheme_actionModeCloseDrawable:I = 0x10

.field public static final SherlockTheme_actionModePopupWindowStyle:I = 0x12

.field public static final SherlockTheme_actionModeShareDrawable:I = 0x11

.field public static final SherlockTheme_actionModeSplitBackground:I = 0xf

.field public static final SherlockTheme_actionModeStyle:I = 0xc

.field public static final SherlockTheme_actionOverflowButtonStyle:I = 0x3

.field public static final SherlockTheme_actionSpinnerItemStyle:I = 0x39

.field public static final SherlockTheme_activatedBackgroundIndicator:I = 0x41

.field public static final SherlockTheme_activityChooserViewStyle:I = 0x40

.field public static final SherlockTheme_buttonStyleSmall:I = 0x13

.field public static final SherlockTheme_dividerVertical:I = 0x32

.field public static final SherlockTheme_dropDownHintAppearance:I = 0x42

.field public static final SherlockTheme_dropDownListViewStyle:I = 0x36

.field public static final SherlockTheme_dropdownListPreferredItemHeight:I = 0x38

.field public static final SherlockTheme_homeAsUpIndicator:I = 0x35

.field public static final SherlockTheme_listPopupWindowStyle:I = 0x3f

.field public static final SherlockTheme_listPreferredItemHeightSmall:I = 0x2c

.field public static final SherlockTheme_listPreferredItemPaddingLeft:I = 0x2d

.field public static final SherlockTheme_listPreferredItemPaddingRight:I = 0x2e

.field public static final SherlockTheme_popupMenuStyle:I = 0x37

.field public static final SherlockTheme_searchAutoCompleteTextView:I = 0x1e

.field public static final SherlockTheme_searchDropdownBackground:I = 0x1f

.field public static final SherlockTheme_searchResultListItemHeight:I = 0x29

.field public static final SherlockTheme_searchViewCloseIcon:I = 0x20

.field public static final SherlockTheme_searchViewEditQuery:I = 0x24

.field public static final SherlockTheme_searchViewEditQueryBackground:I = 0x25

.field public static final SherlockTheme_searchViewGoIcon:I = 0x21

.field public static final SherlockTheme_searchViewSearchIcon:I = 0x22

.field public static final SherlockTheme_searchViewTextField:I = 0x26

.field public static final SherlockTheme_searchViewTextFieldRight:I = 0x27

.field public static final SherlockTheme_searchViewVoiceIcon:I = 0x23

.field public static final SherlockTheme_selectableItemBackground:I = 0x14

.field public static final SherlockTheme_spinnerDropDownItemStyle:I = 0x1d

.field public static final SherlockTheme_spinnerItemStyle:I = 0x1c

.field public static final SherlockTheme_textAppearanceLargePopupMenu:I = 0x16

.field public static final SherlockTheme_textAppearanceListItemSmall:I = 0x2f

.field public static final SherlockTheme_textAppearanceSearchResultSubtitle:I = 0x2b

.field public static final SherlockTheme_textAppearanceSearchResultTitle:I = 0x2a

.field public static final SherlockTheme_textAppearanceSmall:I = 0x18

.field public static final SherlockTheme_textAppearanceSmallPopupMenu:I = 0x17

.field public static final SherlockTheme_textColorPrimary:I = 0x19

.field public static final SherlockTheme_textColorPrimaryDisableOnly:I = 0x1a

.field public static final SherlockTheme_textColorPrimaryInverse:I = 0x1b

.field public static final SherlockTheme_textColorSearchUrl:I = 0x28

.field public static final SherlockTheme_windowActionBar:I = 0x3b

.field public static final SherlockTheme_windowActionBarOverlay:I = 0x3c

.field public static final SherlockTheme_windowActionModeOverlay:I = 0x3d

.field public static final SherlockTheme_windowContentOverlay:I = 0x15

.field public static final SherlockTheme_windowMinWidthMajor:I = 0x30

.field public static final SherlockTheme_windowMinWidthMinor:I = 0x31

.field public static final SherlockTheme_windowNoTitle:I = 0x3a

.field public static final SherlockTheme_windowSplitActionBar:I = 0x3e

.field public static final SherlockView:[I

.field public static final SherlockView_android_focusable:I


# direct methods
.method static constructor <clinit>()V
    .registers 6

    .prologue
    const/16 v5, 0x8

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v2, 0x0

    .line 1362
    const/16 v0, 0x13

    new-array v0, v0, [I

    fill-array-data v0, :array_60

    sput-object v0, Lorg/pornaway/R$styleable;->SherlockActionBar:[I

    .line 1620
    new-array v0, v3, [I

    const v1, 0x101013f

    aput v1, v0, v2

    sput-object v0, Lorg/pornaway/R$styleable;->SherlockActionMenuItemView:[I

    .line 1647
    new-array v0, v4, [I

    fill-array-data v0, :array_8a

    sput-object v0, Lorg/pornaway/R$styleable;->SherlockActionMode:[I

    .line 1725
    const/4 v0, 0x3

    new-array v0, v0, [I

    fill-array-data v0, :array_98

    sput-object v0, Lorg/pornaway/R$styleable;->SherlockActivityChooserView:[I

    .line 1778
    const/4 v0, 0x6

    new-array v0, v0, [I

    fill-array-data v0, :array_a2

    sput-object v0, Lorg/pornaway/R$styleable;->SherlockMenuGroup:[I

    .line 1860
    const/16 v0, 0x11

    new-array v0, v0, [I

    fill-array-data v0, :array_b2

    sput-object v0, Lorg/pornaway/R$styleable;->SherlockMenuItem:[I

    .line 1993
    new-array v0, v5, [I

    fill-array-data v0, :array_d8

    sput-object v0, Lorg/pornaway/R$styleable;->SherlockMenuView:[I

    .line 2107
    new-array v0, v4, [I

    fill-array-data v0, :array_ec

    sput-object v0, Lorg/pornaway/R$styleable;->SherlockSearchView:[I

    .line 2181
    new-array v0, v5, [I

    fill-array-data v0, :array_fa

    sput-object v0, Lorg/pornaway/R$styleable;->SherlockSpinner:[I

    .line 2375
    const/16 v0, 0x43

    new-array v0, v0, [I

    fill-array-data v0, :array_10e

    sput-object v0, Lorg/pornaway/R$styleable;->SherlockTheme:[I

    .line 3169
    new-array v0, v3, [I

    const v1, 0x10100da

    aput v1, v0, v2

    sput-object v0, Lorg/pornaway/R$styleable;->SherlockView:[I

    return-void

    .line 1362
    nop

    :array_60
    .array-data 4
        0x7f010000
        0x7f010001
        0x7f010002
        0x7f010003
        0x7f010004
        0x7f010005
        0x7f010006
        0x7f010007
        0x7f010008
        0x7f010009
        0x7f01000a
        0x7f01000b
        0x7f01000c
        0x7f01000d
        0x7f01000e
        0x7f01000f
        0x7f010010
        0x7f010011
        0x7f010012
    .end array-data

    .line 1647
    :array_8a
    .array-data 4
        0x7f010000
        0x7f010001
        0x7f010003
        0x7f010004
        0x7f010005
    .end array-data

    .line 1725
    :array_98
    .array-data 4
        0x10100d4
        0x7f010013
        0x7f010014
    .end array-data

    .line 1778
    :array_a2
    .array-data 4
        0x101000e
        0x10100d0
        0x1010194
        0x10101de
        0x10101df
        0x10101e0
    .end array-data

    .line 1860
    :array_b2
    .array-data 4
        0x1010002
        0x101000e
        0x10100d0
        0x1010106
        0x1010194
        0x10101de
        0x10101df
        0x10101e1
        0x10101e2
        0x10101e3
        0x10101e4
        0x10101e5
        0x101026f
        0x10102d9
        0x10102fb
        0x10102fc
        0x1010389
    .end array-data

    .line 1993
    :array_d8
    .array-data 4
        0x7f010015
        0x7f010016
        0x7f010017
        0x7f010018
        0x7f010019
        0x7f01001a
        0x7f01001b
        0x7f01001c
    .end array-data

    .line 2107
    :array_ec
    .array-data 4
        0x101011f
        0x1010220
        0x1010264
        0x7f01001d
        0x7f01001e
    .end array-data

    .line 2181
    :array_fa
    .array-data 4
        0x10100af
        0x1010175
        0x1010176
        0x101017b
        0x1010262
        0x10102ac
        0x10102ad
        0x116005e
    .end array-data

    .line 2375
    :array_10e
    .array-data 4
        0x7f01001f
        0x7f010020
        0x7f010021
        0x7f010022
        0x7f010023
        0x7f010024
        0x7f010025
        0x7f010026
        0x7f010027
        0x7f010028
        0x7f010029
        0x7f01002a
        0x7f01002b
        0x7f01002c
        0x7f01002d
        0x7f01002e
        0x7f01002f
        0x7f010030
        0x7f010031
        0x7f010032
        0x7f010033
        0x7f010034
        0x7f010035
        0x7f010036
        0x7f010037
        0x7f010038
        0x7f010039
        0x7f01003a
        0x7f01003b
        0x7f01003c
        0x7f01003d
        0x7f01003e
        0x7f01003f
        0x7f010040
        0x7f010041
        0x7f010042
        0x7f010043
        0x7f010044
        0x7f010045
        0x7f010046
        0x7f010047
        0x7f010048
        0x7f010049
        0x7f01004a
        0x7f01004b
        0x7f01004c
        0x7f01004d
        0x7f01004e
        0x7f01004f
        0x7f010050
        0x7f010051
        0x7f010052
        0x7f010053
        0x7f010054
        0x7f010055
        0x7f010056
        0x7f010057
        0x7f010058
        0x7f010059
        0x7f01005a
        0x7f01005b
        0x7f01005c
        0x7f01005d
        0x7f01005e
        0x7f01005f
        0x7f010060
        0x7f010061
    .end array-data
.end method

.method public constructor <init>()V
    .registers 1

    .prologue
    .line 1315
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
