.class public interface abstract Lorg/pornaway/provider/PornAwayDatabase$Tables;
.super Ljava/lang/Object;
.source "PornAwayDatabase.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/pornaway/provider/PornAwayDatabase;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "Tables"
.end annotation


# static fields
.field public static final BLACKLIST:Ljava/lang/String; = "blacklist"

.field public static final HOSTS_SOURCES:Ljava/lang/String; = "hosts_sources"

.field public static final REDIRECTION_LIST:Ljava/lang/String; = "redirection_list"

.field public static final WHITELIST:Ljava/lang/String; = "whitelist"
