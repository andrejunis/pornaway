.class interface abstract Lorg/pornaway/provider/PornAwayContract$RedirectionListColumns;
.super Ljava/lang/Object;
.source "PornAwayContract.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/pornaway/provider/PornAwayContract;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "RedirectionListColumns"
.end annotation


# static fields
.field public static final ENABLED:Ljava/lang/String; = "enabled"

.field public static final HOSTNAME:Ljava/lang/String; = "url"

.field public static final IP:Ljava/lang/String; = "ip"
