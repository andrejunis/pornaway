.class interface abstract Lorg/pornaway/provider/PornAwayContract$HostsSourcesColumns;
.super Ljava/lang/Object;
.source "PornAwayContract.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/pornaway/provider/PornAwayContract;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "HostsSourcesColumns"
.end annotation


# static fields
.field public static final ENABLED:Ljava/lang/String; = "enabled"

.field public static final LAST_MODIFIED_LOCAL:Ljava/lang/String; = "last_modified_local"

.field public static final LAST_MODIFIED_ONLINE:Ljava/lang/String; = "last_modified_online"

.field public static final URL:Ljava/lang/String; = "url"
