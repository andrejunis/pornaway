.class public final Lorg/pornaway/R$layout;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/pornaway/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "layout"
.end annotation


# static fields
.field public static final abs__action_bar_home:I = 0x7f040000

.field public static final abs__action_bar_tab:I = 0x7f040001

.field public static final abs__action_bar_tab_bar_view:I = 0x7f040002

.field public static final abs__action_bar_title_item:I = 0x7f040003

.field public static final abs__action_menu_item_layout:I = 0x7f040004

.field public static final abs__action_menu_layout:I = 0x7f040005

.field public static final abs__action_mode_bar:I = 0x7f040006

.field public static final abs__action_mode_close_item:I = 0x7f040007

.field public static final abs__activity_chooser_view:I = 0x7f040008

.field public static final abs__activity_chooser_view_list_item:I = 0x7f040009

.field public static final abs__list_menu_item_checkbox:I = 0x7f04000a

.field public static final abs__list_menu_item_icon:I = 0x7f04000b

.field public static final abs__list_menu_item_radio:I = 0x7f04000c

.field public static final abs__popup_menu_item_layout:I = 0x7f04000d

.field public static final abs__screen_action_bar:I = 0x7f04000e

.field public static final abs__screen_action_bar_overlay:I = 0x7f04000f

.field public static final abs__screen_simple:I = 0x7f040010

.field public static final abs__screen_simple_overlay_action_mode:I = 0x7f040011

.field public static final abs__search_dropdown_item_icons_2line:I = 0x7f040012

.field public static final abs__search_view:I = 0x7f040013

.field public static final abs__simple_dropdown_hint:I = 0x7f040014

.field public static final base_activity:I = 0x7f040015

.field public static final base_fragment:I = 0x7f040016

.field public static final checkbox_list_entry:I = 0x7f040017

.field public static final checkbox_list_two_entry:I = 0x7f040018

.field public static final donations__fragment:I = 0x7f040019

.field public static final donations__fragment_bitcoin:I = 0x7f04001a

.field public static final donations__fragment_flattr:I = 0x7f04001b

.field public static final donations__fragment_google:I = 0x7f04001c

.field public static final donations__fragment_paypal:I = 0x7f04001d

.field public static final help_activity:I = 0x7f04001e

.field public static final help_fragment_about:I = 0x7f04001f

.field public static final hosts_sources_activity:I = 0x7f040020

.field public static final lists_activity:I = 0x7f040021

.field public static final lists_hostname_dialog:I = 0x7f040022

.field public static final lists_redirection_dialog:I = 0x7f040023

.field public static final lists_url_dialog:I = 0x7f040024

.field public static final lists_whitelist_hostname_dialog:I = 0x7f040025

.field public static final no_root_dialog:I = 0x7f040026

.field public static final reboot_dialog:I = 0x7f040027

.field public static final scan_adware_activity:I = 0x7f040028

.field public static final sherlock_spinner_dropdown_item:I = 0x7f040029

.field public static final sherlock_spinner_item:I = 0x7f04002a

.field public static final tcpdump_activity:I = 0x7f04002b

.field public static final tcpdump_log_activity:I = 0x7f04002c

.field public static final webserver_fragment:I = 0x7f04002d


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 889
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
