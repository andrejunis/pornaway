.class public final Lorg/pornaway/R$style;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/pornaway/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "style"
.end annotation


# static fields
.field public static final Sherlock___TextAppearance_Small:I = 0x7f0c0040

.field public static final Sherlock___Theme:I = 0x7f0c0000

.field public static final Sherlock___Theme_DarkActionBar:I = 0x7f0c0002

.field public static final Sherlock___Theme_Light:I = 0x7f0c0001

.field public static final Sherlock___Widget_ActionBar:I = 0x7f0c0041

.field public static final Sherlock___Widget_ActionMode:I = 0x7f0c0042

.field public static final Sherlock___Widget_ActivityChooserView:I = 0x7f0c0043

.field public static final Sherlock___Widget_Holo_DropDownItem:I = 0x7f0c0044

.field public static final Sherlock___Widget_Holo_ListView:I = 0x7f0c0045

.field public static final Sherlock___Widget_Holo_Spinner:I = 0x7f0c0046

.field public static final Sherlock___Widget_SearchAutoCompleteTextView:I = 0x7f0c0047

.field public static final TextAppearance_Sherlock:I = 0x7f0c0048

.field public static final TextAppearance_Sherlock_Light_SearchResult:I = 0x7f0c0049

.field public static final TextAppearance_Sherlock_Light_SearchResult_Subtitle:I = 0x7f0c004a

.field public static final TextAppearance_Sherlock_Light_SearchResult_Title:I = 0x7f0c004b

.field public static final TextAppearance_Sherlock_Light_Small:I = 0x7f0c004c

.field public static final TextAppearance_Sherlock_Light_Widget_PopupMenu_Large:I = 0x7f0c0003

.field public static final TextAppearance_Sherlock_Light_Widget_PopupMenu_Small:I = 0x7f0c0004

.field public static final TextAppearance_Sherlock_SearchResult:I = 0x7f0c004d

.field public static final TextAppearance_Sherlock_SearchResult_Subtitle:I = 0x7f0c004e

.field public static final TextAppearance_Sherlock_SearchResult_Title:I = 0x7f0c004f

.field public static final TextAppearance_Sherlock_Small:I = 0x7f0c0050

.field public static final TextAppearance_Sherlock_Widget_ActionBar_Menu:I = 0x7f0c0005

.field public static final TextAppearance_Sherlock_Widget_ActionBar_Subtitle:I = 0x7f0c0006

.field public static final TextAppearance_Sherlock_Widget_ActionBar_Subtitle_Inverse:I = 0x7f0c0007

.field public static final TextAppearance_Sherlock_Widget_ActionBar_Title:I = 0x7f0c0008

.field public static final TextAppearance_Sherlock_Widget_ActionBar_Title_Inverse:I = 0x7f0c0009

.field public static final TextAppearance_Sherlock_Widget_ActionMode_Subtitle:I = 0x7f0c000a

.field public static final TextAppearance_Sherlock_Widget_ActionMode_Subtitle_Inverse:I = 0x7f0c000b

.field public static final TextAppearance_Sherlock_Widget_ActionMode_Title:I = 0x7f0c000c

.field public static final TextAppearance_Sherlock_Widget_ActionMode_Title_Inverse:I = 0x7f0c000d

.field public static final TextAppearance_Sherlock_Widget_DropDownHint:I = 0x7f0c0051

.field public static final TextAppearance_Sherlock_Widget_DropDownItem:I = 0x7f0c0052

.field public static final TextAppearance_Sherlock_Widget_PopupMenu:I = 0x7f0c000e

.field public static final TextAppearance_Sherlock_Widget_PopupMenu_Large:I = 0x7f0c000f

.field public static final TextAppearance_Sherlock_Widget_PopupMenu_Small:I = 0x7f0c0010

.field public static final TextAppearance_Sherlock_Widget_TextView_SpinnerItem:I = 0x7f0c0053

.field public static final Theme_Sherlock:I = 0x7f0c0054

.field public static final Theme_Sherlock_Light:I = 0x7f0c0055

.field public static final Theme_Sherlock_Light_DarkActionBar:I = 0x7f0c0056

.field public static final Theme_Sherlock_Light_NoActionBar:I = 0x7f0c0011

.field public static final Theme_Sherlock_NoActionBar:I = 0x7f0c0012

.field public static final Theme_pornaway:I = 0x7f0c0038

.field public static final Widget:I = 0x7f0c0057

.field public static final Widget_Sherlock_ActionBar:I = 0x7f0c0013

.field public static final Widget_Sherlock_ActionBar_Solid:I = 0x7f0c0014

.field public static final Widget_Sherlock_ActionBar_TabBar:I = 0x7f0c0015

.field public static final Widget_Sherlock_ActionBar_TabText:I = 0x7f0c0016

.field public static final Widget_Sherlock_ActionBar_TabView:I = 0x7f0c0017

.field public static final Widget_Sherlock_ActionButton:I = 0x7f0c0018

.field public static final Widget_Sherlock_ActionButton_CloseMode:I = 0x7f0c0019

.field public static final Widget_Sherlock_ActionButton_Overflow:I = 0x7f0c001a

.field public static final Widget_Sherlock_ActionMode:I = 0x7f0c001b

.field public static final Widget_Sherlock_ActivityChooserView:I = 0x7f0c0058

.field public static final Widget_Sherlock_Button_Small:I = 0x7f0c0059

.field public static final Widget_Sherlock_DropDownItem_Spinner:I = 0x7f0c005a

.field public static final Widget_Sherlock_Light_ActionBar:I = 0x7f0c001c

.field public static final Widget_Sherlock_Light_ActionBar_Solid:I = 0x7f0c001d

.field public static final Widget_Sherlock_Light_ActionBar_Solid_Inverse:I = 0x7f0c001e

.field public static final Widget_Sherlock_Light_ActionBar_TabBar:I = 0x7f0c001f

.field public static final Widget_Sherlock_Light_ActionBar_TabBar_Inverse:I = 0x7f0c0020

.field public static final Widget_Sherlock_Light_ActionBar_TabText:I = 0x7f0c0021

.field public static final Widget_Sherlock_Light_ActionBar_TabText_Inverse:I = 0x7f0c0022

.field public static final Widget_Sherlock_Light_ActionBar_TabView:I = 0x7f0c0023

.field public static final Widget_Sherlock_Light_ActionBar_TabView_Inverse:I = 0x7f0c0024

.field public static final Widget_Sherlock_Light_ActionButton:I = 0x7f0c0025

.field public static final Widget_Sherlock_Light_ActionButton_CloseMode:I = 0x7f0c0026

.field public static final Widget_Sherlock_Light_ActionButton_Overflow:I = 0x7f0c0027

.field public static final Widget_Sherlock_Light_ActionMode:I = 0x7f0c0028

.field public static final Widget_Sherlock_Light_ActionMode_Inverse:I = 0x7f0c0029

.field public static final Widget_Sherlock_Light_ActivityChooserView:I = 0x7f0c005b

.field public static final Widget_Sherlock_Light_Button_Small:I = 0x7f0c005c

.field public static final Widget_Sherlock_Light_DropDownItem_Spinner:I = 0x7f0c005d

.field public static final Widget_Sherlock_Light_ListPopupWindow:I = 0x7f0c005e

.field public static final Widget_Sherlock_Light_ListView_DropDown:I = 0x7f0c002a

.field public static final Widget_Sherlock_Light_PopupMenu:I = 0x7f0c002b

.field public static final Widget_Sherlock_Light_PopupWindow_ActionMode:I = 0x7f0c002c

.field public static final Widget_Sherlock_Light_ProgressBar:I = 0x7f0c002d

.field public static final Widget_Sherlock_Light_ProgressBar_Horizontal:I = 0x7f0c002e

.field public static final Widget_Sherlock_Light_SearchAutoCompleteTextView:I = 0x7f0c002f

.field public static final Widget_Sherlock_Light_Spinner_DropDown_ActionBar:I = 0x7f0c0030

.field public static final Widget_Sherlock_ListPopupWindow:I = 0x7f0c005f

.field public static final Widget_Sherlock_ListView_DropDown:I = 0x7f0c0031

.field public static final Widget_Sherlock_PopupMenu:I = 0x7f0c0032

.field public static final Widget_Sherlock_PopupWindow_ActionMode:I = 0x7f0c0033

.field public static final Widget_Sherlock_ProgressBar:I = 0x7f0c0034

.field public static final Widget_Sherlock_ProgressBar_Horizontal:I = 0x7f0c0035

.field public static final Widget_Sherlock_SearchAutoCompleteTextView:I = 0x7f0c0036

.field public static final Widget_Sherlock_Spinner_DropDown_ActionBar:I = 0x7f0c0037

.field public static final Widget_Sherlock_TextView_SpinnerItem:I = 0x7f0c0060

.field public static final pornaway_ActionBarTabStyle:I = 0x7f0c0039

.field public static final pornaway_DropDownListView:I = 0x7f0c003a

.field public static final pornaway_DropDownNav:I = 0x7f0c003b

.field public static final pornaway_PopupMenu:I = 0x7f0c003c

.field public static final pornaway_ProgressBar:I = 0x7f0c003d

.field public static final pornaway_solid_ActionBar:I = 0x7f0c003e

.field public static final pornaway_transparent_ActionBar:I = 0x7f0c003f


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 1211
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
