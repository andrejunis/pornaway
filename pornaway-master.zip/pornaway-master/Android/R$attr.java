.class public final Lorg/pornaway/R$attr;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/pornaway/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "attr"
.end annotation


# static fields
.field public static final actionBarDivider:I = 0x7f010027

.field public static final actionBarItemBackground:I = 0x7f010028

.field public static final actionBarSize:I = 0x7f010026

.field public static final actionBarSplitStyle:I = 0x7f010024

.field public static final actionBarStyle:I = 0x7f010023

.field public static final actionBarTabBarStyle:I = 0x7f010020

.field public static final actionBarTabStyle:I = 0x7f01001f

.field public static final actionBarTabTextStyle:I = 0x7f010021

.field public static final actionBarWidgetTheme:I = 0x7f010025

.field public static final actionButtonStyle:I = 0x7f010053

.field public static final actionDropDownStyle:I = 0x7f010052

.field public static final actionMenuTextAppearance:I = 0x7f010029

.field public static final actionMenuTextColor:I = 0x7f01002a

.field public static final actionModeBackground:I = 0x7f01002d

.field public static final actionModeCloseButtonStyle:I = 0x7f01002c

.field public static final actionModeCloseDrawable:I = 0x7f01002f

.field public static final actionModePopupWindowStyle:I = 0x7f010031

.field public static final actionModeShareDrawable:I = 0x7f010030

.field public static final actionModeSplitBackground:I = 0x7f01002e

.field public static final actionModeStyle:I = 0x7f01002b

.field public static final actionOverflowButtonStyle:I = 0x7f010022

.field public static final actionSpinnerItemStyle:I = 0x7f010058

.field public static final activatedBackgroundIndicator:I = 0x7f010060

.field public static final activityChooserViewStyle:I = 0x7f01005f

.field public static final background:I = 0x7f010000

.field public static final backgroundSplit:I = 0x7f010001

.field public static final backgroundStacked:I = 0x7f01000c

.field public static final buttonStyleSmall:I = 0x7f010032

.field public static final customNavigationLayout:I = 0x7f01000d

.field public static final displayOptions:I = 0x7f010007

.field public static final divider:I = 0x7f010002

.field public static final dividerVertical:I = 0x7f010051

.field public static final dropDownHintAppearance:I = 0x7f010061

.field public static final dropDownListViewStyle:I = 0x7f010055

.field public static final dropdownListPreferredItemHeight:I = 0x7f010057

.field public static final expandActivityOverflowButtonDrawable:I = 0x7f010014

.field public static final headerBackground:I = 0x7f010018

.field public static final height:I = 0x7f010003

.field public static final homeAsUpIndicator:I = 0x7f010054

.field public static final homeLayout:I = 0x7f01000e

.field public static final horizontalDivider:I = 0x7f010016

.field public static final icon:I = 0x7f01000a

.field public static final iconifiedByDefault:I = 0x7f01001d

.field public static final indeterminateProgressStyle:I = 0x7f010010

.field public static final initialActivityCount:I = 0x7f010013

.field public static final itemBackground:I = 0x7f010019

.field public static final itemIconDisabledAlpha:I = 0x7f01001b

.field public static final itemPadding:I = 0x7f010012

.field public static final itemTextAppearance:I = 0x7f010015

.field public static final listPopupWindowStyle:I = 0x7f01005e

.field public static final listPreferredItemHeightSmall:I = 0x7f01004b

.field public static final listPreferredItemPaddingLeft:I = 0x7f01004c

.field public static final listPreferredItemPaddingRight:I = 0x7f01004d

.field public static final logo:I = 0x7f01000b

.field public static final navigationMode:I = 0x7f010006

.field public static final popupMenuStyle:I = 0x7f010056

.field public static final preserveIconSpacing:I = 0x7f01001c

.field public static final progressBarPadding:I = 0x7f010011

.field public static final progressBarStyle:I = 0x7f01000f

.field public static final queryHint:I = 0x7f01001e

.field public static final searchAutoCompleteTextView:I = 0x7f01003d

.field public static final searchDropdownBackground:I = 0x7f01003e

.field public static final searchResultListItemHeight:I = 0x7f010048

.field public static final searchViewCloseIcon:I = 0x7f01003f

.field public static final searchViewEditQuery:I = 0x7f010043

.field public static final searchViewEditQueryBackground:I = 0x7f010044

.field public static final searchViewGoIcon:I = 0x7f010040

.field public static final searchViewSearchIcon:I = 0x7f010041

.field public static final searchViewTextField:I = 0x7f010045

.field public static final searchViewTextFieldRight:I = 0x7f010046

.field public static final searchViewVoiceIcon:I = 0x7f010042

.field public static final selectableItemBackground:I = 0x7f010033

.field public static final spinnerDropDownItemStyle:I = 0x7f01003c

.field public static final spinnerItemStyle:I = 0x7f01003b

.field public static final subtitle:I = 0x7f010009

.field public static final subtitleTextStyle:I = 0x7f010004

.field public static final textAppearanceLargePopupMenu:I = 0x7f010035

.field public static final textAppearanceListItemSmall:I = 0x7f01004e

.field public static final textAppearanceSearchResultSubtitle:I = 0x7f01004a

.field public static final textAppearanceSearchResultTitle:I = 0x7f010049

.field public static final textAppearanceSmall:I = 0x7f010037

.field public static final textAppearanceSmallPopupMenu:I = 0x7f010036

.field public static final textColorPrimary:I = 0x7f010038

.field public static final textColorPrimaryDisableOnly:I = 0x7f010039

.field public static final textColorPrimaryInverse:I = 0x7f01003a

.field public static final textColorSearchUrl:I = 0x7f010047

.field public static final title:I = 0x7f010008

.field public static final titleTextStyle:I = 0x7f010005

.field public static final verticalDivider:I = 0x7f010017

.field public static final windowActionBar:I = 0x7f01005a

.field public static final windowActionBarOverlay:I = 0x7f01005b

.field public static final windowActionModeOverlay:I = 0x7f01005c

.field public static final windowAnimationStyle:I = 0x7f01001a

.field public static final windowContentOverlay:I = 0x7f010034

.field public static final windowMinWidthMajor:I = 0x7f01004f

.field public static final windowMinWidthMinor:I = 0x7f010050

.field public static final windowNoTitle:I = 0x7f010059

.field public static final windowSplitActionBar:I = 0x7f01005d


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
