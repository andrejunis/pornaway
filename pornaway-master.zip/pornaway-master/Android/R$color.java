.class public final Lorg/pornaway/R$color;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/pornaway/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "color"
.end annotation


# static fields
.field public static final abs__background_holo_dark:I = 0x7f0d0005

.field public static final abs__background_holo_light:I = 0x7f0d0006

.field public static final abs__bright_foreground_disabled_holo_dark:I = 0x7f0d0007

.field public static final abs__bright_foreground_disabled_holo_light:I = 0x7f0d0008

.field public static final abs__bright_foreground_holo_dark:I = 0x7f0d0009

.field public static final abs__bright_foreground_holo_light:I = 0x7f0d000a

.field public static final abs__primary_text_disable_only_holo_dark:I = 0x7f0d000b

.field public static final abs__primary_text_disable_only_holo_light:I = 0x7f0d000c

.field public static final abs__primary_text_holo_dark:I = 0x7f0d000d

.field public static final abs__primary_text_holo_light:I = 0x7f0d000e

.field public static final accent:I = 0x7f0d0000

.field public static final pressed_pornaway:I = 0x7f0d0001

.field public static final primary:I = 0x7f0d0002

.field public static final primary_dark:I = 0x7f0d0003

.field public static final tabsScrollColor:I = 0x7f0d0004


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 588
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
