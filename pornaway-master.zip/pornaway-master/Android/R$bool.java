.class public final Lorg/pornaway/R$bool;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/pornaway/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "bool"
.end annotation


# static fields
.field public static final abs__action_bar_embed_tabs:I = 0x7f0a0001

.field public static final abs__action_bar_expanded_action_views_exclusive:I = 0x7f0a0000

.field public static final abs__config_actionMenuItemAllCaps:I = 0x7f0a0004

.field public static final abs__config_allowActionMenuItemTextWithIcon:I = 0x7f0a0002

.field public static final abs__config_showMenuShortcutsWhenKeyboardPresent:I = 0x7f0a0005

.field public static final abs__split_action_bar_is_narrow:I = 0x7f0a0003


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 580
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
