.class public final Lorg/pornaway/R$id;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/pornaway/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static final abs__action_bar:I = 0x7f0e0020

.field public static final abs__action_bar_container:I = 0x7f0e001f

.field public static final abs__action_bar_subtitle:I = 0x7f0e0011

.field public static final abs__action_bar_title:I = 0x7f0e0010

.field public static final abs__action_context_bar:I = 0x7f0e0021

.field public static final abs__action_menu_divider:I = 0x7f0e0000

.field public static final abs__action_menu_presenter:I = 0x7f0e0001

.field public static final abs__action_mode_bar:I = 0x7f0e0025

.field public static final abs__action_mode_bar_stub:I = 0x7f0e0024

.field public static final abs__action_mode_close_button:I = 0x7f0e0014

.field public static final abs__activity_chooser_view_content:I = 0x7f0e0015

.field public static final abs__checkbox:I = 0x7f0e001c

.field public static final abs__content:I = 0x7f0e0022

.field public static final abs__default_activity_button:I = 0x7f0e0018

.field public static final abs__expand_activities_button:I = 0x7f0e0016

.field public static final abs__home:I = 0x7f0e0002

.field public static final abs__icon:I = 0x7f0e001a

.field public static final abs__image:I = 0x7f0e0017

.field public static final abs__imageButton:I = 0x7f0e0012

.field public static final abs__list_item:I = 0x7f0e0019

.field public static final abs__progress_circular:I = 0x7f0e0003

.field public static final abs__progress_horizontal:I = 0x7f0e0004

.field public static final abs__radio:I = 0x7f0e001d

.field public static final abs__search_badge:I = 0x7f0e0028

.field public static final abs__search_bar:I = 0x7f0e0027

.field public static final abs__search_button:I = 0x7f0e0029

.field public static final abs__search_close_btn:I = 0x7f0e002e

.field public static final abs__search_edit_frame:I = 0x7f0e002a

.field public static final abs__search_go_btn:I = 0x7f0e0030

.field public static final abs__search_mag_icon:I = 0x7f0e002b

.field public static final abs__search_plate:I = 0x7f0e002c

.field public static final abs__search_src_text:I = 0x7f0e002d

.field public static final abs__search_voice_btn:I = 0x7f0e0031

.field public static final abs__shortcut:I = 0x7f0e001e

.field public static final abs__split_action_bar:I = 0x7f0e0023

.field public static final abs__submit_area:I = 0x7f0e002f

.field public static final abs__textButton:I = 0x7f0e0013

.field public static final abs__title:I = 0x7f0e001b

.field public static final abs__up:I = 0x7f0e0005

.field public static final apply_button:I = 0x7f0e003c

.field public static final base_activity_webserver_container:I = 0x7f0e0033

.field public static final base_fragment:I = 0x7f0e0032

.field public static final checkbox_list_checkbox:I = 0x7f0e003e

.field public static final checkbox_list_context_delete:I = 0x7f0e006d

.field public static final checkbox_list_context_edit:I = 0x7f0e006c

.field public static final checkbox_list_two_checkbox:I = 0x7f0e003f

.field public static final checkbox_list_two_subtext:I = 0x7f0e0041

.field public static final checkbox_list_two_text:I = 0x7f0e0040

.field public static final disableHome:I = 0x7f0e0009

.field public static final donations__bitcoin:I = 0x7f0e0049

.field public static final donations__bitcoin_button:I = 0x7f0e004a

.field public static final donations__bitcoin_stub:I = 0x7f0e0048

.field public static final donations__flattr:I = 0x7f0e0043

.field public static final donations__flattr_stub:I = 0x7f0e0042

.field public static final donations__flattr_url:I = 0x7f0e004d

.field public static final donations__flattr_webview:I = 0x7f0e004b

.field public static final donations__google:I = 0x7f0e0045

.field public static final donations__google_android_market_donate_button:I = 0x7f0e004f

.field public static final donations__google_android_market_spinner:I = 0x7f0e004e

.field public static final donations__google_stub:I = 0x7f0e0044

.field public static final donations__loading_frame:I = 0x7f0e004c

.field public static final donations__paypal:I = 0x7f0e0047

.field public static final donations__paypal_donate_button:I = 0x7f0e0050

.field public static final donations__paypal_stub:I = 0x7f0e0046

.field public static final edit_query:I = 0x7f0e0026

.field public static final help_about_text:I = 0x7f0e0053

.field public static final help_about_version:I = 0x7f0e0052

.field public static final homeAsUp:I = 0x7f0e000a

.field public static final horizontalLine:I = 0x7f0e0035

.field public static final hosts_sources_list_footer:I = 0x7f0e0054

.field public static final hosts_sources_list_fragment:I = 0x7f0e0036

.field public static final listMode:I = 0x7f0e0006

.field public static final list_dialog_hostname:I = 0x7f0e0057

.field public static final list_dialog_ip:I = 0x7f0e0058

.field public static final list_dialog_url:I = 0x7f0e0059

.field public static final lists_footer:I = 0x7f0e0055

.field public static final lists_tabs_container:I = 0x7f0e0056

.field public static final menu_add:I = 0x7f0e006e

.field public static final menu_export:I = 0x7f0e0070

.field public static final menu_help:I = 0x7f0e006b

.field public static final menu_hosts_sources:I = 0x7f0e0064

.field public static final menu_import:I = 0x7f0e006f

.field public static final menu_lists:I = 0x7f0e0065

.field public static final menu_preferences:I = 0x7f0e0069

.field public static final menu_refresh:I = 0x7f0e006a

.field public static final menu_scan_adware:I = 0x7f0e0068

.field public static final menu_show_hosts_file:I = 0x7f0e0066

.field public static final menu_tcpdump:I = 0x7f0e0067

.field public static final normal:I = 0x7f0e0007

.field public static final pager:I = 0x7f0e0051

.field public static final reboot_dialog_checkbox:I = 0x7f0e005b

.field public static final reboot_dialog_text:I = 0x7f0e005a

.field public static final revert_button:I = 0x7f0e003d

.field public static final scan_adware_list_container:I = 0x7f0e005d

.field public static final scan_adware_start_button:I = 0x7f0e005c

.field public static final scrollView:I = 0x7f0e0034

.field public static final showCustom:I = 0x7f0e000b

.field public static final showHome:I = 0x7f0e000c

.field public static final showTitle:I = 0x7f0e000d

.field public static final status_icon:I = 0x7f0e0039

.field public static final status_layout:I = 0x7f0e0037

.field public static final status_progress:I = 0x7f0e0038

.field public static final status_text:I = 0x7f0e003b

.field public static final status_title:I = 0x7f0e003a

.field public static final tabMode:I = 0x7f0e0008

.field public static final tcpdump_fragment_delete_button:I = 0x7f0e0060

.field public static final tcpdump_fragment_open_button:I = 0x7f0e005f

.field public static final tcpdump_fragment_toggle_button:I = 0x7f0e005e

.field public static final tcpdump_log_context_blacklist:I = 0x7f0e0071

.field public static final tcpdump_log_context_browser:I = 0x7f0e0073

.field public static final tcpdump_log_context_whitelist:I = 0x7f0e0072

.field public static final tcpdump_log_list_footer:I = 0x7f0e0061

.field public static final tcpdump_log_list_fragment:I = 0x7f0e0062

.field public static final useLogo:I = 0x7f0e000e

.field public static final webserver_fragment_toggle_button:I = 0x7f0e0063

.field public static final wrap_content:I = 0x7f0e000f


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 768
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
