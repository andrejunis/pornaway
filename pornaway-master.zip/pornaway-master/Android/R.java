.class public final Lorg/pornaway/R;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lorg/pornaway/R$styleable;,
        Lorg/pornaway/R$xml;,
        Lorg/pornaway/R$style;,
        Lorg/pornaway/R$string;,
        Lorg/pornaway/R$raw;,
        Lorg/pornaway/R$mipmap;,
        Lorg/pornaway/R$menu;,
        Lorg/pornaway/R$layout;,
        Lorg/pornaway/R$integer;,
        Lorg/pornaway/R$id;,
        Lorg/pornaway/R$drawable;,
        Lorg/pornaway/R$dimen;,
        Lorg/pornaway/R$color;,
        Lorg/pornaway/R$bool;,
        Lorg/pornaway/R$attr;,
        Lorg/pornaway/R$array;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 10
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
