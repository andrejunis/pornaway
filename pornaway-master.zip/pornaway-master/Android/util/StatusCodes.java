.class public Lorg/pornaway/util/StatusCodes;
.super Ljava/lang/Object;
.source "StatusCodes.java"


# static fields
.field public static final APN_PROXY:I = 0x10

.field public static final APPLY_FAIL:I = 0x8

.field public static final CHECKING:I = 0x0

.field public static final COPY_FAIL:I = 0xc

.field public static final DISABLED:I = 0x5

.field public static final DOWNLOAD_FAIL:I = 0x6

.field public static final ENABLED:I = 0x4

.field public static final NOT_ENOUGH_SPACE:I = 0xa

.field public static final NO_CONNECTION:I = 0x7

.field public static final PRIVATE_FILE_FAIL:I = 0x2

.field public static final REMOUNT_FAIL:I = 0xb

.field public static final REVERT_FAIL:I = 0xf

.field public static final REVERT_SUCCESS:I = 0xe

.field public static final SUCCESS:I = 0x1

.field public static final SYMLINK_MISSING:I = 0x9

.field public static final UPDATE_AVAILABLE:I = 0x3


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 26
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
