.class public Lorg/pornaway/ui/ScanAdwareListFragment;
.super Lcom/actionbarsherlock/app/SherlockListFragment;
.source "ScanAdwareListFragment.java"

# interfaces
.implements Landroid/support/v4/app/LoaderManager$LoaderCallbacks;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Lcom/actionbarsherlock/app/SherlockListFragment;",
        "Landroid/support/v4/app/LoaderManager$LoaderCallbacks",
        "<",
        "Ljava/util/List",
        "<",
        "Ljava/util/Map",
        "<",
        "Ljava/lang/String;",
        "Ljava/lang/String;",
        ">;>;>;"
    }
.end annotation


# instance fields
.field private mActivity:Landroid/app/Activity;

.field private mAdapter:Landroid/widget/SimpleAdapter;

.field private mStartButton:Landroid/widget/Button;


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 45
    invoke-direct {p0}, Lcom/actionbarsherlock/app/SherlockListFragment;-><init>()V

    return-void
.end method


# virtual methods
.method public onActivityCreated(Landroid/os/Bundle;)V
    .registers 9
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .prologue
    const/4 v6, 0x0

    .line 86
    invoke-super {p0, p1}, Lcom/actionbarsherlock/app/SherlockListFragment;->onActivityCreated(Landroid/os/Bundle;)V

    .line 88
    invoke-virtual {p0}, Lorg/pornaway/ui/ScanAdwareListFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;

    move-result-object v0

    iput-object v0, p0, Lorg/pornaway/ui/ScanAdwareListFragment;->mActivity:Landroid/app/Activity;

    .line 89
    iget-object v0, p0, Lorg/pornaway/ui/ScanAdwareListFragment;->mActivity:Landroid/app/Activity;

    const v1, 0x7f0e005c

    invoke-virtual {v0, v1}, Landroid/app/Activity;->findViewById(I)Landroid/view/View;

    move-result-object v0

    check-cast v0, Landroid/widget/Button;

    iput-object v0, p0, Lorg/pornaway/ui/ScanAdwareListFragment;->mStartButton:Landroid/widget/Button;

    .line 92
    invoke-virtual {p0}, Lorg/pornaway/ui/ScanAdwareListFragment;->getListView()Landroid/widget/ListView;

    move-result-object v0

    invoke-virtual {p0, v0}, Lorg/pornaway/ui/ScanAdwareListFragment;->registerForContextMenu(Landroid/view/View;)V

    .line 96
    iget-object v0, p0, Lorg/pornaway/ui/ScanAdwareListFragment;->mActivity:Landroid/app/Activity;

    const v1, 0x7f080089

    invoke-virtual {v0, v1}, Landroid/app/Activity;->getString(I)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p0, v0}, Lorg/pornaway/ui/ScanAdwareListFragment;->setEmptyText(Ljava/lang/CharSequence;)V

    .line 99
    new-array v4, v6, [Ljava/lang/String;

    .line 100
    .local v4, "from":[Ljava/lang/String;
    new-array v5, v6, [I

    .line 101
    .local v5, "to":[I
    new-instance v2, Ljava/util/ArrayList;

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 102
    .local v2, "data":Ljava/util/List;, "Ljava/util/List<Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;>;"
    new-instance v0, Landroid/widget/SimpleAdapter;

    invoke-virtual {p0}, Lorg/pornaway/ui/ScanAdwareListFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;

    move-result-object v1

    const v3, 0x109000d

    invoke-direct/range {v0 .. v5}, Landroid/widget/SimpleAdapter;-><init>(Landroid/content/Context;Ljava/util/List;I[Ljava/lang/String;[I)V

    iput-object v0, p0, Lorg/pornaway/ui/ScanAdwareListFragment;->mAdapter:Landroid/widget/SimpleAdapter;

    .line 104
    iget-object v0, p0, Lorg/pornaway/ui/ScanAdwareListFragment;->mAdapter:Landroid/widget/SimpleAdapter;

    invoke-virtual {p0, v0}, Lorg/pornaway/ui/ScanAdwareListFragment;->setListAdapter(Landroid/widget/ListAdapter;)V

    .line 107
    invoke-virtual {p0, v6}, Lorg/pornaway/ui/ScanAdwareListFragment;->setListShown(Z)V

    .line 108
    return-void
.end method

.method public onCreateLoader(ILandroid/os/Bundle;)Landroid/support/v4/content/Loader;
    .registers 5
    .param p1, "id"    # I
    .param p2, "args"    # Landroid/os/Bundle;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Landroid/os/Bundle;",
            ")",
            "Landroid/support/v4/content/Loader",
            "<",
            "Ljava/util/List",
            "<",
            "Ljava/util/Map",
            "<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;>;>;"
        }
    .end annotation

    .prologue
    .line 112
    new-instance v0, Lorg/pornaway/util/ScanAdwareLoader;

    iget-object v1, p0, Lorg/pornaway/ui/ScanAdwareListFragment;->mActivity:Landroid/app/Activity;

    invoke-direct {v0, v1}, Lorg/pornaway/util/ScanAdwareLoader;-><init>(Landroid/content/Context;)V

    return-object v0
.end method

.method public onListItemClick(Landroid/widget/ListView;Landroid/view/View;IJ)V
    .registers 11
    .param p1, "listView"    # Landroid/widget/ListView;
    .param p2, "view"    # Landroid/view/View;
    .param p3, "position"    # I
    .param p4, "id"    # J

    .prologue
    .line 53
    invoke-virtual {p1, p3}, Landroid/widget/ListView;->getItemAtPosition(I)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/util/Map;

    .line 55
    .local v1, "item":Ljava/util/Map;, "Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;"
    const-string v3, "package_name"

    invoke-interface {v1, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    .line 58
    .local v2, "packageName":Ljava/lang/String;
    new-instance v0, Landroid/content/Intent;

    const-string v3, "android.intent.action.DELETE"

    invoke-direct {v0, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 59
    .local v0, "i":Landroid/content/Intent;
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const-string v4, "package:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    invoke-virtual {v0, v3}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    .line 60
    invoke-virtual {p0, v0}, Lorg/pornaway/ui/ScanAdwareListFragment;->startActivity(Landroid/content/Intent;)V

    .line 61
    return-void
.end method

.method public bridge synthetic onLoadFinished(Landroid/support/v4/content/Loader;Ljava/lang/Object;)V
    .registers 3

    .prologue
    .line 45
    check-cast p2, Ljava/util/List;

    invoke-virtual {p0, p1, p2}, Lorg/pornaway/ui/ScanAdwareListFragment;->onLoadFinished(Landroid/support/v4/content/Loader;Ljava/util/List;)V

    return-void
.end method

.method public onLoadFinished(Landroid/support/v4/content/Loader;Ljava/util/List;)V
    .registers 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/support/v4/content/Loader",
            "<",
            "Ljava/util/List",
            "<",
            "Ljava/util/Map",
            "<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;>;>;",
            "Ljava/util/List",
            "<",
            "Ljava/util/Map",
            "<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;>;)V"
        }
    .end annotation

    .prologue
    .local p1, "loader":Landroid/support/v4/content/Loader;, "Landroid/support/v4/content/Loader<Ljava/util/List<Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;>;>;"
    .local p2, "data":Ljava/util/List;, "Ljava/util/List<Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;>;"
    const/4 v3, 0x2

    const/4 v6, 0x1

    .line 122
    const-string v0, "PornAway"

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "data: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v0, v1}, Lorg/pornaway/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 129
    new-array v4, v3, [Ljava/lang/String;

    const/4 v0, 0x0

    const-string v1, "app_name"

    aput-object v1, v4, v0

    const-string v0, "package_name"

    aput-object v0, v4, v6

    .line 130
    .local v4, "from":[Ljava/lang/String;
    new-array v5, v3, [I

    fill-array-data v5, :array_56

    .line 131
    .local v5, "to":[I
    new-instance v0, Landroid/widget/SimpleAdapter;

    invoke-virtual {p0}, Lorg/pornaway/ui/ScanAdwareListFragment;->getActivity()Landroid/support/v4/app/FragmentActivity;

    move-result-object v1

    const v3, 0x109000d

    move-object v2, p2

    invoke-direct/range {v0 .. v5}, Landroid/widget/SimpleAdapter;-><init>(Landroid/content/Context;Ljava/util/List;I[Ljava/lang/String;[I)V

    iput-object v0, p0, Lorg/pornaway/ui/ScanAdwareListFragment;->mAdapter:Landroid/widget/SimpleAdapter;

    .line 134
    iget-object v0, p0, Lorg/pornaway/ui/ScanAdwareListFragment;->mAdapter:Landroid/widget/SimpleAdapter;

    invoke-virtual {v0}, Landroid/widget/SimpleAdapter;->notifyDataSetChanged()V

    .line 135
    iget-object v0, p0, Lorg/pornaway/ui/ScanAdwareListFragment;->mAdapter:Landroid/widget/SimpleAdapter;

    invoke-virtual {p0, v0}, Lorg/pornaway/ui/ScanAdwareListFragment;->setListAdapter(Landroid/widget/ListAdapter;)V

    .line 138
    invoke-virtual {p0}, Lorg/pornaway/ui/ScanAdwareListFragment;->isResumed()Z

    move-result v0

    if-eqz v0, :cond_52

    .line 139
    invoke-virtual {p0, v6}, Lorg/pornaway/ui/ScanAdwareListFragment;->setListShown(Z)V

    .line 145
    :goto_4c
    iget-object v0, p0, Lorg/pornaway/ui/ScanAdwareListFragment;->mStartButton:Landroid/widget/Button;

    invoke-virtual {v0, v6}, Landroid/widget/Button;->setEnabled(Z)V

    .line 146
    return-void

    .line 141
    :cond_52
    invoke-virtual {p0, v6}, Lorg/pornaway/ui/ScanAdwareListFragment;->setListShownNoAnimation(Z)V

    goto :goto_4c

    .line 130
    :array_56
    .array-data 4
        0x1020014
        0x1020015
    .end array-data
.end method

.method public onLoaderReset(Landroid/support/v4/content/Loader;)V
    .registers 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/support/v4/content/Loader",
            "<",
            "Ljava/util/List",
            "<",
            "Ljava/util/Map",
            "<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;>;>;)V"
        }
    .end annotation

    .prologue
    .line 153
    .local p1, "loader":Landroid/support/v4/content/Loader;, "Landroid/support/v4/content/Loader<Ljava/util/List<Ljava/util/Map<Ljava/lang/String;Ljava/lang/String;>;>;>;"
    return-void
.end method

.method public onResume()V
    .registers 4

    .prologue
    const/4 v2, 0x0

    .line 68
    invoke-super {p0}, Lcom/actionbarsherlock/app/SherlockListFragment;->onResume()V

    .line 71
    invoke-virtual {p0, v2}, Lorg/pornaway/ui/ScanAdwareListFragment;->setListShown(Z)V

    .line 74
    iget-object v0, p0, Lorg/pornaway/ui/ScanAdwareListFragment;->mStartButton:Landroid/widget/Button;

    invoke-virtual {v0, v2}, Landroid/widget/Button;->setEnabled(Z)V

    .line 78
    invoke-virtual {p0}, Lorg/pornaway/ui/ScanAdwareListFragment;->getLoaderManager()Landroid/support/v4/app/LoaderManager;

    move-result-object v0

    const/4 v1, 0x0

    invoke-virtual {v0, v2, v1, p0}, Landroid/support/v4/app/LoaderManager;->initLoader(ILandroid/os/Bundle;Landroid/support/v4/app/LoaderManager$LoaderCallbacks;)Landroid/support/v4/content/Loader;

    .line 79
    return-void
.end method
