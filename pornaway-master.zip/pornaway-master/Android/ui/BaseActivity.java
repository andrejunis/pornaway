.class public Lorg/pornaway/ui/BaseActivity;
.super Lcom/actionbarsherlock/app/SherlockFragmentActivity;
.source "BaseActivity.java"


# static fields
.field static final ACTION_BUTTONS:Ljava/lang/String; = "org.pornaway.BUTTONS"

.field static final ACTION_UPDATE_STATUS:Ljava/lang/String; = "org.pornaway.UPDATE_STATUS"

.field public static final EXTRA_APPLYING_RESULT:Ljava/lang/String; = "org.pornaway.APPLYING_RESULT"

.field public static final EXTRA_BUTTONS_DISABLED:Ljava/lang/String; = "org.pornaway.BUTTONS.ENABLED"

.field public static final EXTRA_NUMBER_OF_SUCCESSFUL_DOWNLOADS:Ljava/lang/String; = "org.pornaway.NUMBER_OF_SUCCESSFUL_DOWNLOADS"

.field public static final EXTRA_UPDATE_STATUS_ICON:Ljava/lang/String; = "org.pornaway.UPDATE_STATUS.ICON"

.field public static final EXTRA_UPDATE_STATUS_TEXT:Ljava/lang/String; = "org.pornaway.UPDATE_STATUS.TEXT"

.field public static final EXTRA_UPDATE_STATUS_TITLE:Ljava/lang/String; = "org.pornaway.UPDATE_STATUS.TITLE"


# instance fields
.field mActivity:Landroid/app/Activity;

.field mBaseFragment:Lorg/pornaway/ui/BaseFragment;

.field mFragmentManager:Landroid/support/v4/app/FragmentManager;

.field mLocalBroadcastManager:Landroid/support/v4/content/LocalBroadcastManager;

.field mReceiver:Landroid/content/BroadcastReceiver;

.field mWebserverFragment:Lorg/pornaway/ui/WebserverFragment;


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 49
    invoke-direct {p0}, Lcom/actionbarsherlock/app/SherlockFragmentActivity;-><init>()V

    return-void
.end method

.method public static setButtonsDisabledBroadcast(Landroid/content/Context;Z)V
    .registers 5
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "buttonsDisabled"    # Z

    .prologue
    .line 211
    invoke-static {p0}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;

    move-result-object v1

    .line 213
    .local v1, "localBroadcastManager":Landroid/support/v4/content/LocalBroadcastManager;
    new-instance v0, Landroid/content/Intent;

    const-string v2, "org.pornaway.BUTTONS"

    invoke-direct {v0, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 214
    .local v0, "intent":Landroid/content/Intent;
    const-string v2, "org.pornaway.BUTTONS.ENABLED"

    invoke-virtual {v0, v2, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 215
    invoke-virtual {v1, v0}, Landroid/support/v4/content/LocalBroadcastManager;->sendBroadcast(Landroid/content/Intent;)Z

    .line 216
    return-void
.end method

.method public static setStatusBroadcast(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)V
    .registers 7
    .param p0, "context"    # Landroid/content/Context;
    .param p1, "title"    # Ljava/lang/String;
    .param p2, "text"    # Ljava/lang/String;
    .param p3, "iconStatus"    # I

    .prologue
    .line 195
    invoke-static {p0}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;

    move-result-object v1

    .line 197
    .local v1, "localBroadcastManager":Landroid/support/v4/content/LocalBroadcastManager;
    new-instance v0, Landroid/content/Intent;

    const-string v2, "org.pornaway.UPDATE_STATUS"

    invoke-direct {v0, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    .line 198
    .local v0, "intent":Landroid/content/Intent;
    const-string v2, "org.pornaway.UPDATE_STATUS.ICON"

    invoke-virtual {v0, v2, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    .line 199
    const-string v2, "org.pornaway.UPDATE_STATUS.TITLE"

    invoke-virtual {v0, v2, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 200
    const-string v2, "org.pornaway.UPDATE_STATUS.TEXT"

    invoke-virtual {v0, v2, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    .line 201
    invoke-virtual {v1, v0}, Landroid/support/v4/content/LocalBroadcastManager;->sendBroadcast(Landroid/content/Intent;)Z

    .line 202
    return-void
.end method

.method public static updateStatusDisabled(Landroid/content/Context;)V
    .registers 4
    .param p0, "context"    # Landroid/content/Context;

    .prologue
    .line 234
    const v0, 0x7f08008d

    invoke-virtual {p0, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    const v1, 0x7f08008e

    .line 235
    invoke-virtual {p0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x5

    .line 234
    invoke-static {p0, v0, v1, v2}, Lorg/pornaway/ui/BaseActivity;->setStatusBroadcast(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)V

    .line 236
    return-void
.end method

.method public static updateStatusEnabled(Landroid/content/Context;)V
    .registers 4
    .param p0, "context"    # Landroid/content/Context;

    .prologue
    .line 224
    const v0, 0x7f080091

    invoke-virtual {p0, v0}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v0

    const v1, 0x7f080092

    .line 225
    invoke-virtual {p0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v2, 0x4

    .line 224
    invoke-static {p0, v0, v1, v2}, Lorg/pornaway/ui/BaseActivity;->setStatusBroadcast(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;I)V

    .line 226
    return-void
.end method


# virtual methods
.method public applyOnClick(Landroid/view/View;)V
    .registers 3
    .param p1, "view"    # Landroid/view/View;

    .prologue
    .line 272
    iget-object v0, p0, Lorg/pornaway/ui/BaseActivity;->mBaseFragment:Lorg/pornaway/ui/BaseFragment;

    invoke-virtual {v0, p1}, Lorg/pornaway/ui/BaseFragment;->applyOnClick(Landroid/view/View;)V

    .line 273
    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .registers 7
    .param p1, "savedInstanceState"    # Landroid/os/Bundle;

    .prologue
    const/4 v4, 0x0

    .line 110
    invoke-super {p0, p1}, Lcom/actionbarsherlock/app/SherlockFragmentActivity;->onCreate(Landroid/os/Bundle;)V

    .line 112
    const v2, 0x7f040015

    invoke-virtual {p0, v2}, Lorg/pornaway/ui/BaseActivity;->setContentView(I)V

    .line 114
    iput-object p0, p0, Lorg/pornaway/ui/BaseActivity;->mActivity:Landroid/app/Activity;

    .line 116
    invoke-virtual {p0}, Lorg/pornaway/ui/BaseActivity;->getSupportFragmentManager()Landroid/support/v4/app/FragmentManager;

    move-result-object v2

    iput-object v2, p0, Lorg/pornaway/ui/BaseActivity;->mFragmentManager:Landroid/support/v4/app/FragmentManager;

    .line 117
    iget-object v2, p0, Lorg/pornaway/ui/BaseActivity;->mFragmentManager:Landroid/support/v4/app/FragmentManager;

    const v3, 0x7f0e0032

    invoke-virtual {v2, v3}, Landroid/support/v4/app/FragmentManager;->findFragmentById(I)Landroid/support/v4/app/Fragment;

    move-result-object v2

    check-cast v2, Lorg/pornaway/ui/BaseFragment;

    iput-object v2, p0, Lorg/pornaway/ui/BaseActivity;->mBaseFragment:Lorg/pornaway/ui/BaseFragment;

    .line 120
    invoke-static {p0}, Landroid/support/v4/content/LocalBroadcastManager;->getInstance(Landroid/content/Context;)Landroid/support/v4/content/LocalBroadcastManager;

    move-result-object v2

    iput-object v2, p0, Lorg/pornaway/ui/BaseActivity;->mLocalBroadcastManager:Landroid/support/v4/content/LocalBroadcastManager;

    .line 123
    new-instance v0, Landroid/content/IntentFilter;

    invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V

    .line 124
    .local v0, "filter":Landroid/content/IntentFilter;
    const-string v2, "org.pornaway.UPDATE_STATUS"

    invoke-virtual {v0, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 125
    const-string v2, "org.pornaway.BUTTONS"

    invoke-virtual {v0, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    .line 126
    new-instance v2, Lorg/pornaway/ui/BaseActivity$1;

    invoke-direct {v2, p0}, Lorg/pornaway/ui/BaseActivity$1;-><init>(Lorg/pornaway/ui/BaseActivity;)V

    iput-object v2, p0, Lorg/pornaway/ui/BaseActivity;->mReceiver:Landroid/content/BroadcastReceiver;

    .line 157
    iget-object v2, p0, Lorg/pornaway/ui/BaseActivity;->mLocalBroadcastManager:Landroid/support/v4/content/LocalBroadcastManager;

    iget-object v3, p0, Lorg/pornaway/ui/BaseActivity;->mReceiver:Landroid/content/BroadcastReceiver;

    invoke-virtual {v2, v3, v0}, Landroid/support/v4/content/LocalBroadcastManager;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)V

    .line 160
    iget-object v2, p0, Lorg/pornaway/ui/BaseActivity;->mActivity:Landroid/app/Activity;

    invoke-static {v2}, Lorg/pornaway/util/Utils;->isAndroidRooted(Landroid/app/Activity;)Z

    move-result v2

    if-eqz v2, :cond_79

    .line 163
    if-nez p1, :cond_6f

    .line 165
    sget-object v2, Lorg/pornaway/util/Constants;->ANDROID_SYSTEM_ETC_HOSTS:Ljava/lang/String;

    invoke-static {v2}, Lorg/pornaway/util/ApplyUtils;->isHostsFileCorrect(Ljava/lang/String;)Z

    move-result v2

    if-eqz v2, :cond_80

    .line 168
    iget-object v2, p0, Lorg/pornaway/ui/BaseActivity;->mActivity:Landroid/app/Activity;

    invoke-static {v2}, Lorg/pornaway/helper/PreferenceHelper;->getUpdateCheck(Landroid/content/Context;)Z

    move-result v2

    if-eqz v2, :cond_7a

    .line 169
    new-instance v1, Landroid/content/Intent;

    iget-object v2, p0, Lorg/pornaway/ui/BaseActivity;->mActivity:Landroid/app/Activity;

    const-class v3, Lorg/pornaway/service/UpdateService;

    invoke-direct {v1, v2, v3}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    .line 170
    .local v1, "updateIntent":Landroid/content/Intent;
    const-string v2, "org.pornaway.BACKGROUND_EXECUTION"

    invoke-virtual {v1, v2, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    .line 171
    iget-object v2, p0, Lorg/pornaway/ui/BaseActivity;->mActivity:Landroid/app/Activity;

    invoke-static {v2, v1}, Lcom/commonsware/cwac/wakeful/WakefulIntentService;->sendWakefulWork(Landroid/content/Context;Landroid/content/Intent;)V

    .line 181
    .end local v1    # "updateIntent":Landroid/content/Intent;
    :cond_6f
    :goto_6f
    new-instance v2, Lorg/pornaway/service/DailyListener;

    invoke-direct {v2}, Lorg/pornaway/service/DailyListener;-><init>()V

    iget-object v3, p0, Lorg/pornaway/ui/BaseActivity;->mActivity:Landroid/app/Activity;

    invoke-static {v2, v3, v4}, Lcom/commonsware/cwac/wakeful/WakefulIntentService;->scheduleAlarms(Lcom/commonsware/cwac/wakeful/WakefulIntentService$AlarmListener;Landroid/content/Context;Z)V

    .line 183
    :cond_79
    return-void

    .line 173
    :cond_7a
    iget-object v2, p0, Lorg/pornaway/ui/BaseActivity;->mActivity:Landroid/app/Activity;

    invoke-static {v2}, Lorg/pornaway/ui/BaseActivity;->updateStatusEnabled(Landroid/content/Context;)V

    goto :goto_6f

    .line 176
    :cond_80
    iget-object v2, p0, Lorg/pornaway/ui/BaseActivity;->mActivity:Landroid/app/Activity;

    invoke-static {v2}, Lorg/pornaway/ui/BaseActivity;->updateStatusDisabled(Landroid/content/Context;)V

    goto :goto_6f
.end method

.method protected onNewIntent(Landroid/content/Intent;)V
    .registers 8
    .param p1, "intent"    # Landroid/content/Intent;

    .prologue
    .line 80
    invoke-super {p0, p1}, Lcom/actionbarsherlock/app/SherlockFragmentActivity;->onNewIntent(Landroid/content/Intent;)V

    .line 81
    const-string v3, "PornAway"

    const-string v4, "onNewIntent"

    invoke-static {v3, v4}, Lorg/pornaway/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 84
    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v0

    .line 85
    .local v0, "extras":Landroid/os/Bundle;
    if-eqz v0, :cond_62

    .line 86
    const-string v3, "org.pornaway.APPLYING_RESULT"

    invoke-virtual {v0, v3}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_62

    .line 87
    const-string v3, "org.pornaway.APPLYING_RESULT"

    invoke-virtual {v0, v3}, Landroid/os/Bundle;->getInt(Ljava/lang/String;)I

    move-result v2

    .line 88
    .local v2, "result":I
    const-string v3, "PornAway"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Result from intent extras: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lorg/pornaway/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 91
    const/4 v1, 0x0

    .line 92
    .local v1, "numberOfSuccessfulDownloads":Ljava/lang/String;
    const-string v3, "org.pornaway.NUMBER_OF_SUCCESSFUL_DOWNLOADS"

    invoke-virtual {v0, v3}, Landroid/os/Bundle;->containsKey(Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_5d

    .line 93
    const-string v3, "org.pornaway.NUMBER_OF_SUCCESSFUL_DOWNLOADS"

    .line 94
    invoke-virtual {v0, v3}, Landroid/os/Bundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    .line 95
    const-string v3, "PornAway"

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "Applying information from intent extras: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v3, v4}, Lorg/pornaway/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)V

    .line 99
    :cond_5d
    iget-object v3, p0, Lorg/pornaway/ui/BaseActivity;->mActivity:Landroid/app/Activity;

    .line 100
    invoke-static {v3, v2, v1}, Lorg/pornaway/helper/ResultHelper;->showDialogBasedOnResult(Landroid/content/Context;ILjava/lang/String;)V

    .line 103
    .end local v1    # "numberOfSuccessfulDownloads":Ljava/lang/String;
    .end local v2    # "result":I
    :cond_62
    return-void
.end method

.method protected onStart()V
    .registers 5

    .prologue
    .line 243
    invoke-super {p0}, Lcom/actionbarsherlock/app/SherlockFragmentActivity;->onStart()V

    .line 244
    invoke-virtual {p0}, Lorg/pornaway/ui/BaseActivity;->getSupportActionBar()Lcom/actionbarsherlock/app/ActionBar;

    move-result-object v0

    .line 245
    .local v0, "actionBar":Lcom/actionbarsherlock/app/ActionBar;
    const v2, 0x7f080001

    invoke-virtual {v0, v2}, Lcom/actionbarsherlock/app/ActionBar;->setSubtitle(I)V

    .line 248
    invoke-static {p0}, Lorg/pornaway/helper/PreferenceHelper;->getWebserverEnabled(Landroid/content/Context;)Z

    move-result v2

    if-eqz v2, :cond_2c

    .line 249
    iget-object v2, p0, Lorg/pornaway/ui/BaseActivity;->mFragmentManager:Landroid/support/v4/app/FragmentManager;

    invoke-virtual {v2}, Landroid/support/v4/app/FragmentManager;->beginTransaction()Landroid/support/v4/app/FragmentTransaction;

    move-result-object v1

    .line 251
    .local v1, "fragmentTransaction":Landroid/support/v4/app/FragmentTransaction;
    new-instance v2, Lorg/pornaway/ui/WebserverFragment;

    invoke-direct {v2}, Lorg/pornaway/ui/WebserverFragment;-><init>()V

    iput-object v2, p0, Lorg/pornaway/ui/BaseActivity;->mWebserverFragment:Lorg/pornaway/ui/WebserverFragment;

    .line 253
    const v2, 0x7f0e0033

    iget-object v3, p0, Lorg/pornaway/ui/BaseActivity;->mWebserverFragment:Lorg/pornaway/ui/WebserverFragment;

    invoke-virtual {v1, v2, v3}, Landroid/support/v4/app/FragmentTransaction;->replace(ILandroid/support/v4/app/Fragment;)Landroid/support/v4/app/FragmentTransaction;

    .line 254
    invoke-virtual {v1}, Landroid/support/v4/app/FragmentTransaction;->commit()I

    .line 266
    .end local v1    # "fragmentTransaction":Landroid/support/v4/app/FragmentTransaction;
    :cond_2b
    :goto_2b
    return-void

    .line 257
    :cond_2c
    iget-object v2, p0, Lorg/pornaway/ui/BaseActivity;->mWebserverFragment:Lorg/pornaway/ui/WebserverFragment;

    if-eqz v2, :cond_2b

    .line 258
    iget-object v2, p0, Lorg/pornaway/ui/BaseActivity;->mFragmentManager:Landroid/support/v4/app/FragmentManager;

    invoke-virtual {v2}, Landroid/support/v4/app/FragmentManager;->beginTransaction()Landroid/support/v4/app/FragmentTransaction;

    move-result-object v1

    .line 260
    .restart local v1    # "fragmentTransaction":Landroid/support/v4/app/FragmentTransaction;
    iget-object v2, p0, Lorg/pornaway/ui/BaseActivity;->mWebserverFragment:Lorg/pornaway/ui/WebserverFragment;

    invoke-virtual {v1, v2}, Landroid/support/v4/app/FragmentTransaction;->remove(Landroid/support/v4/app/Fragment;)Landroid/support/v4/app/FragmentTransaction;

    .line 261
    invoke-virtual {v1}, Landroid/support/v4/app/FragmentTransaction;->commit()I

    .line 263
    const/4 v2, 0x0

    iput-object v2, p0, Lorg/pornaway/ui/BaseActivity;->mWebserverFragment:Lorg/pornaway/ui/WebserverFragment;

    goto :goto_2b
.end method

.method public revertOnClick(Landroid/view/View;)V
    .registers 3
    .param p1, "view"    # Landroid/view/View;

    .prologue
    .line 279
    iget-object v0, p0, Lorg/pornaway/ui/BaseActivity;->mBaseFragment:Lorg/pornaway/ui/BaseFragment;

    invoke-virtual {v0, p1}, Lorg/pornaway/ui/BaseFragment;->revertOnClick(Landroid/view/View;)V

    .line 280
    return-void
.end method

.method public webserverOnClick(Landroid/view/View;)V
    .registers 3
    .param p1, "view"    # Landroid/view/View;

    .prologue
    .line 286
    iget-object v0, p0, Lorg/pornaway/ui/BaseActivity;->mWebserverFragment:Lorg/pornaway/ui/WebserverFragment;

    invoke-virtual {v0, p1}, Lorg/pornaway/ui/WebserverFragment;->webserverOnClick(Landroid/view/View;)V

    .line 287
    return-void
.end method
