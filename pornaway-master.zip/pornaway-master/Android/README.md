
#### Includes the java files inside the android apk version, a fork of AdAway.

Link to the original thread for the Android version: https://forum.xda-developers.com/android/apps-games/root-pornaway-block-porn-sites-t3460036
