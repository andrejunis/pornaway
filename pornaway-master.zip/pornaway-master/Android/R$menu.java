.class public final Lorg/pornaway/R$menu;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/pornaway/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "menu"
.end annotation


# static fields
.field public static final base:I = 0x7f0f0000

.field public static final checkbox_list_context:I = 0x7f0f0001

.field public static final hosts_sources_fragment:I = 0x7f0f0002

.field public static final lists_activity:I = 0x7f0f0003

.field public static final lists_fragment:I = 0x7f0f0004

.field public static final tcpdump_log_context:I = 0x7f0f0005


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 937
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
