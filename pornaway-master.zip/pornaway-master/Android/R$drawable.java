.class public final Lorg/pornaway/R$drawable;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/pornaway/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "drawable"
.end annotation


# static fields
.field public static final ab_bottom_solid_pornaway:I = 0x7f020000

.field public static final ab_solid_pornaway:I = 0x7f020001

.field public static final ab_stacked_solid_pornaway:I = 0x7f020002

.field public static final ab_transparent_pornaway:I = 0x7f020003

.field public static final abs__ab_bottom_solid_dark_holo:I = 0x7f020004

.field public static final abs__ab_bottom_solid_inverse_holo:I = 0x7f020005

.field public static final abs__ab_bottom_solid_light_holo:I = 0x7f020006

.field public static final abs__ab_bottom_transparent_dark_holo:I = 0x7f020007

.field public static final abs__ab_bottom_transparent_light_holo:I = 0x7f020008

.field public static final abs__ab_share_pack_holo_dark:I = 0x7f020009

.field public static final abs__ab_share_pack_holo_light:I = 0x7f02000a

.field public static final abs__ab_solid_dark_holo:I = 0x7f02000b

.field public static final abs__ab_solid_light_holo:I = 0x7f02000c

.field public static final abs__ab_solid_shadow_holo:I = 0x7f02000d

.field public static final abs__ab_stacked_solid_dark_holo:I = 0x7f02000e

.field public static final abs__ab_stacked_solid_light_holo:I = 0x7f02000f

.field public static final abs__ab_stacked_transparent_dark_holo:I = 0x7f020010

.field public static final abs__ab_stacked_transparent_light_holo:I = 0x7f020011

.field public static final abs__ab_transparent_dark_holo:I = 0x7f020012

.field public static final abs__ab_transparent_light_holo:I = 0x7f020013

.field public static final abs__activated_background_holo_dark:I = 0x7f020014

.field public static final abs__activated_background_holo_light:I = 0x7f020015

.field public static final abs__btn_cab_done_default_holo_dark:I = 0x7f020016

.field public static final abs__btn_cab_done_default_holo_light:I = 0x7f020017

.field public static final abs__btn_cab_done_focused_holo_dark:I = 0x7f020018

.field public static final abs__btn_cab_done_focused_holo_light:I = 0x7f020019

.field public static final abs__btn_cab_done_holo_dark:I = 0x7f02001a

.field public static final abs__btn_cab_done_holo_light:I = 0x7f02001b

.field public static final abs__btn_cab_done_pressed_holo_dark:I = 0x7f02001c

.field public static final abs__btn_cab_done_pressed_holo_light:I = 0x7f02001d

.field public static final abs__cab_background_bottom_holo_dark:I = 0x7f02001e

.field public static final abs__cab_background_bottom_holo_light:I = 0x7f02001f

.field public static final abs__cab_background_top_holo_dark:I = 0x7f020020

.field public static final abs__cab_background_top_holo_light:I = 0x7f020021

.field public static final abs__ic_ab_back_holo_dark:I = 0x7f020022

.field public static final abs__ic_ab_back_holo_light:I = 0x7f020023

.field public static final abs__ic_cab_done_holo_dark:I = 0x7f020024

.field public static final abs__ic_cab_done_holo_light:I = 0x7f020025

.field public static final abs__ic_clear:I = 0x7f020026

.field public static final abs__ic_clear_disabled:I = 0x7f020027

.field public static final abs__ic_clear_holo_light:I = 0x7f020028

.field public static final abs__ic_clear_normal:I = 0x7f020029

.field public static final abs__ic_clear_search_api_disabled_holo_light:I = 0x7f02002a

.field public static final abs__ic_clear_search_api_holo_light:I = 0x7f02002b

.field public static final abs__ic_commit_search_api_holo_dark:I = 0x7f02002c

.field public static final abs__ic_commit_search_api_holo_light:I = 0x7f02002d

.field public static final abs__ic_go:I = 0x7f02002e

.field public static final abs__ic_go_search_api_holo_light:I = 0x7f02002f

.field public static final abs__ic_menu_moreoverflow_holo_dark:I = 0x7f020030

.field public static final abs__ic_menu_moreoverflow_holo_light:I = 0x7f020031

.field public static final abs__ic_menu_moreoverflow_normal_holo_dark:I = 0x7f020032

.field public static final abs__ic_menu_moreoverflow_normal_holo_light:I = 0x7f020033

.field public static final abs__ic_menu_share_holo_dark:I = 0x7f020034

.field public static final abs__ic_menu_share_holo_light:I = 0x7f020035

.field public static final abs__ic_search:I = 0x7f020036

.field public static final abs__ic_search_api_holo_light:I = 0x7f020037

.field public static final abs__ic_voice_search:I = 0x7f020038

.field public static final abs__ic_voice_search_api_holo_light:I = 0x7f020039

.field public static final abs__item_background_holo_dark:I = 0x7f02003a

.field public static final abs__item_background_holo_light:I = 0x7f02003b

.field public static final abs__list_activated_holo:I = 0x7f02003c

.field public static final abs__list_divider_holo_dark:I = 0x7f02003d

.field public static final abs__list_divider_holo_light:I = 0x7f02003e

.field public static final abs__list_focused_holo:I = 0x7f02003f

.field public static final abs__list_longpressed_holo:I = 0x7f020040

.field public static final abs__list_pressed_holo_dark:I = 0x7f020041

.field public static final abs__list_pressed_holo_light:I = 0x7f020042

.field public static final abs__list_selector_background_transition_holo_dark:I = 0x7f020043

.field public static final abs__list_selector_background_transition_holo_light:I = 0x7f020044

.field public static final abs__list_selector_disabled_holo_dark:I = 0x7f020045

.field public static final abs__list_selector_disabled_holo_light:I = 0x7f020046

.field public static final abs__list_selector_holo_dark:I = 0x7f020047

.field public static final abs__list_selector_holo_light:I = 0x7f020048

.field public static final abs__menu_dropdown_panel_holo_dark:I = 0x7f020049

.field public static final abs__menu_dropdown_panel_holo_light:I = 0x7f02004a

.field public static final abs__progress_bg_holo_dark:I = 0x7f02004b

.field public static final abs__progress_bg_holo_light:I = 0x7f02004c

.field public static final abs__progress_horizontal_holo_dark:I = 0x7f02004d

.field public static final abs__progress_horizontal_holo_light:I = 0x7f02004e

.field public static final abs__progress_medium_holo:I = 0x7f02004f

.field public static final abs__progress_primary_holo_dark:I = 0x7f020050

.field public static final abs__progress_primary_holo_light:I = 0x7f020051

.field public static final abs__progress_secondary_holo_dark:I = 0x7f020052

.field public static final abs__progress_secondary_holo_light:I = 0x7f020053

.field public static final abs__search_dropdown_dark:I = 0x7f020054

.field public static final abs__search_dropdown_light:I = 0x7f020055

.field public static final abs__spinner_48_inner_holo:I = 0x7f020056

.field public static final abs__spinner_48_outer_holo:I = 0x7f020057

.field public static final abs__spinner_ab_default_holo_dark:I = 0x7f020058

.field public static final abs__spinner_ab_default_holo_light:I = 0x7f020059

.field public static final abs__spinner_ab_disabled_holo_dark:I = 0x7f02005a

.field public static final abs__spinner_ab_disabled_holo_light:I = 0x7f02005b

.field public static final abs__spinner_ab_focused_holo_dark:I = 0x7f02005c

.field public static final abs__spinner_ab_focused_holo_light:I = 0x7f02005d

.field public static final abs__spinner_ab_holo_dark:I = 0x7f02005e

.field public static final abs__spinner_ab_holo_light:I = 0x7f02005f

.field public static final abs__spinner_ab_pressed_holo_dark:I = 0x7f020060

.field public static final abs__spinner_ab_pressed_holo_light:I = 0x7f020061

.field public static final abs__tab_indicator_ab_holo:I = 0x7f020062

.field public static final abs__tab_selected_focused_holo:I = 0x7f020063

.field public static final abs__tab_selected_holo:I = 0x7f020064

.field public static final abs__tab_selected_pressed_holo:I = 0x7f020065

.field public static final abs__tab_unselected_pressed_holo:I = 0x7f020066

.field public static final abs__textfield_search_default_holo_dark:I = 0x7f020067

.field public static final abs__textfield_search_default_holo_light:I = 0x7f020068

.field public static final abs__textfield_search_right_default_holo_dark:I = 0x7f020069

.field public static final abs__textfield_search_right_default_holo_light:I = 0x7f02006a

.field public static final abs__textfield_search_right_selected_holo_dark:I = 0x7f02006b

.field public static final abs__textfield_search_right_selected_holo_light:I = 0x7f02006c

.field public static final abs__textfield_search_selected_holo_dark:I = 0x7f02006d

.field public static final abs__textfield_search_selected_holo_light:I = 0x7f02006e

.field public static final abs__textfield_searchview_holo_dark:I = 0x7f02006f

.field public static final abs__textfield_searchview_holo_light:I = 0x7f020070

.field public static final abs__textfield_searchview_right_holo_dark:I = 0x7f020071

.field public static final abs__textfield_searchview_right_holo_light:I = 0x7f020072

.field public static final abs__toast_frame:I = 0x7f020073

.field public static final action_help:I = 0x7f020074

.field public static final action_new:I = 0x7f020075

.field public static final action_refresh:I = 0x7f020076

.field public static final list_focused_pornaway:I = 0x7f020077

.field public static final menu_dropdown_panel_pornaway:I = 0x7f020078

.field public static final menu_hardkey_panel_pornaway:I = 0x7f020079

.field public static final pressed_background_pornaway:I = 0x7f02007a

.field public static final progress_bg_pornaway:I = 0x7f02007b

.field public static final progress_horizontal_pornaway:I = 0x7f02007c

.field public static final progress_primary_pornaway:I = 0x7f02007d

.field public static final progress_secondary_pornaway:I = 0x7f02007e

.field public static final selectable_background_pornaway:I = 0x7f02007f

.field public static final spinner_ab_default_pornaway:I = 0x7f020080

.field public static final spinner_ab_disabled_pornaway:I = 0x7f020081

.field public static final spinner_ab_focused_pornaway:I = 0x7f020082

.field public static final spinner_ab_pressed_pornaway:I = 0x7f020083

.field public static final spinner_background_ab_pornaway:I = 0x7f020084

.field public static final status_bar_icon:I = 0x7f020085

.field public static final status_disabled:I = 0x7f020086

.field public static final status_enabled:I = 0x7f020087

.field public static final status_fail:I = 0x7f020088

.field public static final status_update:I = 0x7f020089

.field public static final tab_indicator_ab_pornaway:I = 0x7f02008a

.field public static final tab_selected_pornaway:I = 0x7f02008b

.field public static final tab_selected_focused_pornaway:I = 0x7f02008c

.field public static final tab_selected_pressed_pornaway:I = 0x7f02008d


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 622
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
