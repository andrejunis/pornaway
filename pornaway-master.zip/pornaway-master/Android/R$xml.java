.class public final Lorg/pornaway/R$xml;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/pornaway/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "xml"
.end annotation


# static fields
.field public static final preferences:I = 0x7f050000

.field public static final shortcuts:I = 0x7f050001

.field public static final wakeful:I = 0x7f050002


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 1310
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
