.class public final Lorg/pornaway/R$string;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/pornaway/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "string"
.end annotation


# static fields
.field public static final about_url:I = 0x7f0800cc

.field public static final abs__action_bar_home_description:I = 0x7f0800cd

.field public static final abs__action_bar_up_description:I = 0x7f0800ce

.field public static final abs__action_menu_overflow_description:I = 0x7f0800cf

.field public static final abs__action_mode_done:I = 0x7f0800d0

.field public static final abs__activity_chooser_view_see_all:I = 0x7f0800d1

.field public static final abs__activitychooserview_choose_application:I = 0x7f0800d2

.field public static final abs__searchview_description_clear:I = 0x7f0800d3

.field public static final abs__searchview_description_query:I = 0x7f0800d4

.field public static final abs__searchview_description_search:I = 0x7f0800d5

.field public static final abs__searchview_description_submit:I = 0x7f0800d6

.field public static final abs__searchview_description_voice:I = 0x7f0800d7

.field public static final abs__shareactionprovider_share_with:I = 0x7f0800d8

.field public static final abs__shareactionprovider_share_with_application:I = 0x7f0800d9

.field public static final app_name:I = 0x7f080000

.field public static final app_subtitle:I = 0x7f080001

.field public static final apply_apn_proxy:I = 0x7f0800a1

.field public static final apply_apn_proxy_title:I = 0x7f080002

.field public static final apply_copy_fail:I = 0x7f080003

.field public static final apply_copy_fail_title:I = 0x7f080004

.field public static final apply_dialog:I = 0x7f080005

.field public static final apply_dialog_apply:I = 0x7f080006

.field public static final apply_dialog_hostnames:I = 0x7f080007

.field public static final apply_dialog_hosts:I = 0x7f080008

.field public static final apply_dialog_lists:I = 0x7f080009

.field public static final apply_fail:I = 0x7f0800a2

.field public static final apply_fail_title:I = 0x7f08000a

.field public static final apply_help:I = 0x7f08000b

.field public static final apply_not_enough_space:I = 0x7f0800a3

.field public static final apply_not_enough_space_title:I = 0x7f08000c

.field public static final apply_private_file_fail:I = 0x7f08000d

.field public static final apply_private_file_fail_title:I = 0x7f08000e

.field public static final apply_remount_fail:I = 0x7f08000f

.field public static final apply_remount_fail_title:I = 0x7f080010

.field public static final apply_success_dialog:I = 0x7f0800a4

.field public static final apply_success_subtitle:I = 0x7f080011

.field public static final apply_success_title:I = 0x7f080012

.field public static final apply_symlink_fail:I = 0x7f0800a5

.field public static final apply_symlink_fail_title:I = 0x7f080013

.field public static final apply_symlink_missing:I = 0x7f0800a6

.field public static final apply_symlink_missing_title:I = 0x7f080014

.field public static final apply_symlink_successful:I = 0x7f0800a7

.field public static final apply_symlink_successful_title:I = 0x7f080015

.field public static final button_add:I = 0x7f080016

.field public static final button_apply:I = 0x7f080017

.field public static final button_apply_text:I = 0x7f080018

.field public static final button_cancel:I = 0x7f080019

.field public static final button_close:I = 0x7f08001a

.field public static final button_exit:I = 0x7f08001b

.field public static final button_help:I = 0x7f08001c

.field public static final button_no:I = 0x7f08001d

.field public static final button_revert:I = 0x7f08001e

.field public static final button_revert_text:I = 0x7f08001f

.field public static final button_save:I = 0x7f080020

.field public static final button_tcpdump_delete:I = 0x7f080021

.field public static final button_tcpdump_open:I = 0x7f080022

.field public static final button_tcpdump_text:I = 0x7f080023

.field public static final button_tcpdump_toggle_checked:I = 0x7f080024

.field public static final button_tcpdump_toggle_unchecked:I = 0x7f080025

.field public static final button_webserver_toggle_checked:I = 0x7f080026

.field public static final button_webserver_toggle_text:I = 0x7f080027

.field public static final button_webserver_toggle_unchecked:I = 0x7f080028

.field public static final button_yes:I = 0x7f080029

.field public static final checkbox_list_add_dialog_title:I = 0x7f08002a

.field public static final checkbox_list_context_delete:I = 0x7f08002b

.field public static final checkbox_list_context_edit:I = 0x7f08002c

.field public static final checkbox_list_context_title:I = 0x7f08002d

.field public static final checkbox_list_edit_dialog_title:I = 0x7f08002e

.field public static final checkbox_list_empty:I = 0x7f08002f

.field public static final checkbox_list_empty_text:I = 0x7f080030

.field public static final checkbox_list_footer:I = 0x7f080031

.field public static final disable_systemless_successful:I = 0x7f0800b3

.field public static final disable_systemless_successful_title:I = 0x7f0800b4

.field public static final donations__alert_dialog_no_browser:I = 0x7f0800b5

.field public static final donations__alert_dialog_title:I = 0x7f0800b6

.field public static final donations__bitcoin:I = 0x7f0800da

.field public static final donations__bitcoin_description:I = 0x7f0800c9

.field public static final donations__bitcoin_send_bitcoin_button:I = 0x7f0800ca

.field public static final donations__bitcoin_toast_copy:I = 0x7f0800cb

.field public static final donations__button_close:I = 0x7f0800b7

.field public static final donations__description:I = 0x7f0800b8

.field public static final donations__flattr:I = 0x7f0800b9

.field public static final donations__flattr_description:I = 0x7f0800ba

.field public static final donations__google_android_market:I = 0x7f0800bb

.field public static final donations__google_android_market_description:I = 0x7f0800bc

.field public static final donations__google_android_market_donate_button:I = 0x7f0800bd

.field public static final donations__google_android_market_not_supported:I = 0x7f0800be

.field public static final donations__google_android_market_not_supported_title:I = 0x7f0800bf

.field public static final donations__google_android_market_text:I = 0x7f0800c0

.field public static final donations__paypal:I = 0x7f0800c1

.field public static final donations__paypal_description:I = 0x7f0800c2

.field public static final donations__thanks_dialog:I = 0x7f0800c3

.field public static final donations__thanks_dialog_title:I = 0x7f0800c4

.field public static final download_dialog:I = 0x7f080032

.field public static final download_fail_dialog:I = 0x7f080033

.field public static final download_fail_title:I = 0x7f080034

.field public static final export_dialog:I = 0x7f080035

.field public static final export_success:I = 0x7f080036

.field public static final help_about_version:I = 0x7f080037

.field public static final help_donation_paypal_item:I = 0x7f080038

.field public static final help_tab_about:I = 0x7f080039

.field public static final help_tab_changelog:I = 0x7f08003a

.field public static final help_tab_donate:I = 0x7f08003b

.field public static final help_tab_faq:I = 0x7f08003c

.field public static final help_tab_problems:I = 0x7f08003d

.field public static final help_tab_s_on_s_off:I = 0x7f08003e

.field public static final hosts_add_dialog:I = 0x7f08003f

.field public static final hosts_add_dialog_input:I = 0x7f0800db

.field public static final hosts_last_modified_local:I = 0x7f080040

.field public static final hosts_last_modified_online:I = 0x7f080041

.field public static final hosts_not_available:I = 0x7f080042

.field public static final import_dialog:I = 0x7f080043

.field public static final list_dialog_hostname:I = 0x7f080044

.field public static final list_dialog_ip:I = 0x7f080045

.field public static final list_dialog_url:I = 0x7f080046

.field public static final list_dialog_whitelist_hostname:I = 0x7f0800a8

.field public static final lists_tab_blacklist:I = 0x7f080047

.field public static final lists_tab_blacklist_short:I = 0x7f080048

.field public static final lists_tab_redirection_list:I = 0x7f080049

.field public static final lists_tab_redirection_list_short:I = 0x7f08004a

.field public static final lists_tab_whitelist:I = 0x7f08004b

.field public static final lists_tab_whitelist_short:I = 0x7f08004c

.field public static final loading:I = 0x7f08004d

.field public static final menu_add:I = 0x7f08004e

.field public static final menu_export:I = 0x7f08004f

.field public static final menu_help:I = 0x7f080050

.field public static final menu_hosts_sources:I = 0x7f080051

.field public static final menu_import:I = 0x7f080052

.field public static final menu_lists:I = 0x7f080053

.field public static final menu_preferences:I = 0x7f080054

.field public static final menu_refresh:I = 0x7f080055

.field public static final menu_scan_adware:I = 0x7f080056

.field public static final menu_show_hosts_file:I = 0x7f080057

.field public static final menu_tcpdump:I = 0x7f080058

.field public static final no_connection:I = 0x7f080059

.field public static final no_connection_title:I = 0x7f08005a

.field public static final no_file_manager:I = 0x7f0800a9

.field public static final no_file_manager_title:I = 0x7f08005b

.field public static final no_hostname:I = 0x7f08005c

.field public static final no_hostname_title:I = 0x7f08005d

.field public static final no_ip:I = 0x7f08005e

.field public static final no_ip_title:I = 0x7f08005f

.field public static final no_private_file:I = 0x7f080060

.field public static final no_private_file_title:I = 0x7f080061

.field public static final no_root_description:I = 0x7f0800aa

.field public static final no_root_title:I = 0x7f080062

.field public static final no_root_url:I = 0x7f0800dc

.field public static final no_text_editor:I = 0x7f0800ab

.field public static final no_text_editor_title:I = 0x7f080063

.field public static final no_url:I = 0x7f080064

.field public static final no_url_title:I = 0x7f080065

.field public static final pref_apply_method:I = 0x7f080066

.field public static final pref_apply_method_def:I = 0x7f0800dd

.field public static final pref_apply_method_key:I = 0x7f0800de

.field public static final pref_apply_method_summary:I = 0x7f080067

.field public static final pref_automatic_update_daily:I = 0x7f080068

.field public static final pref_automatic_update_daily_def:I = 0x7f0800df

.field public static final pref_automatic_update_daily_key:I = 0x7f0800e0

.field public static final pref_automatic_update_daily_summary:I = 0x7f080069

.field public static final pref_background:I = 0x7f08006a

.field public static final pref_custom_target:I = 0x7f08006b

.field public static final pref_custom_target_def:I = 0x7f0800e1

.field public static final pref_custom_target_key:I = 0x7f0800e2

.field public static final pref_custom_target_summary:I = 0x7f08006c

.field public static final pref_debug:I = 0x7f08006d

.field public static final pref_download:I = 0x7f08006e

.field public static final pref_enable_debug:I = 0x7f08006f

.field public static final pref_enable_debug_def:I = 0x7f0800e3

.field public static final pref_enable_debug_key:I = 0x7f0800e4

.field public static final pref_enable_debug_summary:I = 0x7f080070

.field public static final pref_enable_ipv6:I = 0x7f0800ac

.field public static final pref_enable_ipv6_def:I = 0x7f0800e5

.field public static final pref_enable_ipv6_key:I = 0x7f0800e6

.field public static final pref_enable_ipv6_summary:I = 0x7f0800ad

.field public static final pref_enable_systemless:I = 0x7f0800c5

.field public static final pref_enable_systemless_def:I = 0x7f0800c6

.field public static final pref_enable_systemless_key:I = 0x7f0800c7

.field public static final pref_enable_systemless_summary:I = 0x7f0800c8

.field public static final pref_header_preferences:I = 0x7f080071

.field public static final pref_header_preferences_summary:I = 0x7f080072

.field public static final pref_hosts:I = 0x7f080073

.field public static final pref_never_reboot:I = 0x7f080074

.field public static final pref_never_reboot_def:I = 0x7f0800e7

.field public static final pref_never_reboot_key:I = 0x7f0800e8

.field public static final pref_never_reboot_summary:I = 0x7f080075

.field public static final pref_redirection_ip:I = 0x7f080076

.field public static final pref_redirection_ip_def:I = 0x7f0800e9

.field public static final pref_redirection_ip_key:I = 0x7f0800ea

.field public static final pref_redirection_ip_summary:I = 0x7f080077

.field public static final pref_redirection_rules:I = 0x7f0800ae

.field public static final pref_redirection_rules_def:I = 0x7f0800eb

.field public static final pref_redirection_rules_key:I = 0x7f0800ec

.field public static final pref_redirection_rules_summary:I = 0x7f0800af

.field public static final pref_sdcard_problem:I = 0x7f080078

.field public static final pref_tcpdump_version_def:I = 0x7f0800ed

.field public static final pref_tcpdump_version_key:I = 0x7f0800ee

.field public static final pref_update_check:I = 0x7f080079

.field public static final pref_update_check_daily:I = 0x7f08007a

.field public static final pref_update_check_daily_def:I = 0x7f0800ef

.field public static final pref_update_check_daily_key:I = 0x7f0800f0

.field public static final pref_update_check_daily_summary:I = 0x7f08007b

.field public static final pref_update_check_def:I = 0x7f0800f1

.field public static final pref_update_check_key:I = 0x7f0800f2

.field public static final pref_update_check_summary:I = 0x7f08007c

.field public static final pref_update_only_on_wifi:I = 0x7f08007d

.field public static final pref_update_only_on_wifi_def:I = 0x7f0800f3

.field public static final pref_update_only_on_wifi_key:I = 0x7f0800f4

.field public static final pref_update_only_on_wifi_summary:I = 0x7f08007e

.field public static final pref_webserver:I = 0x7f08007f

.field public static final pref_webserver_enabled:I = 0x7f080080

.field public static final pref_webserver_enabled_def:I = 0x7f0800f5

.field public static final pref_webserver_enabled_key:I = 0x7f0800f6

.field public static final pref_webserver_enabled_summary:I = 0x7f080081

.field public static final pref_webserver_on_boot:I = 0x7f080082

.field public static final pref_webserver_on_boot_def:I = 0x7f0800f7

.field public static final pref_webserver_on_boot_key:I = 0x7f0800f8

.field public static final pref_webserver_on_boot_summary:I = 0x7f080083

.field public static final pref_webserver_version_def:I = 0x7f0800f9

.field public static final pref_webserver_version_key:I = 0x7f0800fa

.field public static final pref_whitelist_rules:I = 0x7f0800b0

.field public static final pref_whitelist_rules_def:I = 0x7f0800fb

.field public static final pref_whitelist_rules_key:I = 0x7f0800fc

.field public static final pref_whitelist_rules_summary:I = 0x7f0800b1

.field public static final reboot_never_reboot:I = 0x7f080084

.field public static final revert_problem:I = 0x7f080085

.field public static final revert_problem_title:I = 0x7f080086

.field public static final revert_successful:I = 0x7f0800b2

.field public static final revert_successful_title:I = 0x7f080087

.field public static final scan_adware_description:I = 0x7f080088

.field public static final scan_adware_empty:I = 0x7f080089

.field public static final scan_adware_start:I = 0x7f08008a

.field public static final status_checking:I = 0x7f08008b

.field public static final status_checking_subtitle:I = 0x7f08008c

.field public static final status_disabled:I = 0x7f08008d

.field public static final status_disabled_subtitle:I = 0x7f08008e

.field public static final status_download_fail:I = 0x7f08008f

.field public static final status_download_fail_subtitle_new:I = 0x7f080090

.field public static final status_enabled:I = 0x7f080091

.field public static final status_enabled_subtitle:I = 0x7f080092

.field public static final status_no_connection:I = 0x7f080093

.field public static final status_no_connection_subtitle:I = 0x7f080094

.field public static final status_reverting:I = 0x7f080095

.field public static final status_reverting_subtitle:I = 0x7f080096

.field public static final status_update_available:I = 0x7f080097

.field public static final status_update_available_subtitle:I = 0x7f080098

.field public static final tcpdump_log_context_blacklist:I = 0x7f080099

.field public static final tcpdump_log_context_browser:I = 0x7f08009a

.field public static final tcpdump_log_context_whitelist:I = 0x7f08009b

.field public static final tcpdump_log_empty:I = 0x7f08009c

.field public static final tcpdump_log_footer:I = 0x7f08009d

.field public static final toast_tcpdump_added_to_blacklist:I = 0x7f08009e

.field public static final toast_tcpdump_added_to_whitelist:I = 0x7f08009f

.field public static final toast_tcpdump_log_deleted:I = 0x7f0800a0


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 956
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
