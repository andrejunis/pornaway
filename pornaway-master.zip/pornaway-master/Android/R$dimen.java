.class public final Lorg/pornaway/R$dimen;
.super Ljava/lang/Object;
.source "R.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lorg/pornaway/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "dimen"
.end annotation


# static fields
.field public static final abs__action_bar_default_height:I = 0x7f090000

.field public static final abs__action_bar_icon_vertical_padding:I = 0x7f090001

.field public static final abs__action_bar_subtitle_bottom_margin:I = 0x7f090002

.field public static final abs__action_bar_subtitle_text_size:I = 0x7f090003

.field public static final abs__action_bar_subtitle_top_margin:I = 0x7f090004

.field public static final abs__action_bar_title_text_size:I = 0x7f090005

.field public static final abs__action_button_min_width:I = 0x7f090006

.field public static final abs__config_prefDialogWidth:I = 0x7f090009

.field public static final abs__dialog_min_width_major:I = 0x7f090007

.field public static final abs__dialog_min_width_minor:I = 0x7f090008

.field public static final abs__dropdownitem_icon_width:I = 0x7f09000a

.field public static final abs__dropdownitem_text_padding_left:I = 0x7f09000b

.field public static final abs__dropdownitem_text_padding_right:I = 0x7f09000c

.field public static final abs__search_view_preferred_width:I = 0x7f09000d

.field public static final abs__search_view_text_min_width:I = 0x7f09000e


# direct methods
.method public constructor <init>()V
    .registers 1

    .prologue
    .line 605
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
