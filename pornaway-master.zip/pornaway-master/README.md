# ![enter image description here](https://s14.postimg.org/un3rkzxch/cat_32x.png "pornaway-icon") PornAway
###### Blocks porn sites & ads using `hosts` ⦁ App available for Android

PornAway provides `hosts` file to enable devices to block porn sites and related ads. An android app has been released on [XDA](https://forum.xda-developers.com/android/apps-games/root-pornaway-block-porn-sites-t3460036). You can use the hosts file to work on any machine. Hit Google to know how to enable hosts file on your OS or browser.



***Check out the hosts file to know more about them.*** 
